"use strict";
(() => {
var exports = {};
exports.id = 505;
exports.ids = [505];
exports.modules = {

/***/ 5547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Components)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(8308);
// EXTERNAL MODULE: ./components/Header/Header.js + 1 modules
var Header = __webpack_require__(9152);
// EXTERNAL MODULE: ./components/Header/HeaderLinks.js
var HeaderLinks = __webpack_require__(5017);
// EXTERNAL MODULE: ./components/Footer/Footer.js + 1 modules
var Footer = __webpack_require__(6356);
// EXTERNAL MODULE: ./components/Grid/GridContainer.js
var GridContainer = __webpack_require__(4041);
// EXTERNAL MODULE: ./components/Grid/GridItem.js
var GridItem = __webpack_require__(6680);
// EXTERNAL MODULE: ./components/CustomButtons/Button.js + 1 modules
var Button = __webpack_require__(4286);
// EXTERNAL MODULE: ./components/Parallax/Parallax.js + 1 modules
var Parallax = __webpack_require__(8602);
;// CONCATENATED MODULE: external "nouislider"
const external_nouislider_namespaceObject = require("nouislider");
var external_nouislider_default = /*#__PURE__*/__webpack_require__.n(external_nouislider_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/InputAdornment"
const InputAdornment_namespaceObject = require("@material-ui/core/InputAdornment");
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/FormControlLabel"
const FormControlLabel_namespaceObject = require("@material-ui/core/FormControlLabel");
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/Checkbox"
const Checkbox_namespaceObject = require("@material-ui/core/Checkbox");
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/Radio"
const Radio_namespaceObject = require("@material-ui/core/Radio");
var Radio_default = /*#__PURE__*/__webpack_require__.n(Radio_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/Switch"
const Switch_namespaceObject = require("@material-ui/core/Switch");
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch_namespaceObject);
// EXTERNAL MODULE: external "@material-ui/icons/Favorite"
var Favorite_ = __webpack_require__(9899);
var Favorite_default = /*#__PURE__*/__webpack_require__.n(Favorite_);
;// CONCATENATED MODULE: external "@material-ui/icons/People"
const People_namespaceObject = require("@material-ui/icons/People");
var People_default = /*#__PURE__*/__webpack_require__.n(People_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/Check"
const Check_namespaceObject = require("@material-ui/icons/Check");
var Check_default = /*#__PURE__*/__webpack_require__.n(Check_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/FiberManualRecord"
const FiberManualRecord_namespaceObject = require("@material-ui/icons/FiberManualRecord");
var FiberManualRecord_default = /*#__PURE__*/__webpack_require__.n(FiberManualRecord_namespaceObject);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "@material-ui/core/FormControl"
var FormControl_ = __webpack_require__(5811);
var FormControl_default = /*#__PURE__*/__webpack_require__.n(FormControl_);
// EXTERNAL MODULE: external "@material-ui/core/InputLabel"
var InputLabel_ = __webpack_require__(8190);
var InputLabel_default = /*#__PURE__*/__webpack_require__.n(InputLabel_);
// EXTERNAL MODULE: external "@material-ui/core/Input"
var Input_ = __webpack_require__(3302);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input_);
// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit/components/customInputStyle.js
var customInputStyle = __webpack_require__(3341);
;// CONCATENATED MODULE: ./components/CustomInput/CustomInput.js


// nodejs library to set properties for components

// nodejs library that concatenates classes

// @material-ui/core components





const useStyles = (0,styles_.makeStyles)(customInputStyle/* default */.Z);
function CustomInput(props) {
    const classes = useStyles();
    const { formControlProps , labelText , labelProps , error , white , inputRootCustomClasses , success  } = props;
    const labelClasses = external_classnames_default()({
        [" " + classes.labelRootError]: error,
        [" " + classes.labelRootSuccess]: success && !error
    });
    const underlineClasses = external_classnames_default()({
        [classes.underlineError]: error,
        [classes.underlineSuccess]: success && !error,
        [classes.underline]: true,
        [classes.whiteUnderline]: white
    });
    const marginTop = external_classnames_default()({
        [inputRootCustomClasses]: inputRootCustomClasses !== undefined
    });
    const inputClasses = external_classnames_default()({
        [classes.input]: true,
        [classes.whiteInput]: white
    });
    var formControlClasses;
    if (formControlProps !== undefined) {
        formControlClasses = external_classnames_default()(formControlProps.className, classes.formControl);
    } else {
        formControlClasses = classes.formControl;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((FormControl_default()), {
        ...formControlProps,
        className: formControlClasses,
        children: [
            labelText !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                className: classes.labelRoot + " " + labelClasses,
                ...labelProps,
                children: labelText
            }) : null,
            /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                classes: {
                    input: inputClasses,
                    root: marginTop,
                    disabled: classes.disabled,
                    underline: underlineClasses
                }
            })
        ]
    });
};
CustomInput.propTypes = {
    labelText: (external_prop_types_default()).node,
    labelProps: (external_prop_types_default()).object,
    formControlProps: (external_prop_types_default()).object,
    inputRootCustomClasses: (external_prop_types_default()).string,
    error: (external_prop_types_default()).bool,
    success: (external_prop_types_default()).bool,
    white: (external_prop_types_default()).bool
};

;// CONCATENATED MODULE: external "@material-ui/core/LinearProgress"
const LinearProgress_namespaceObject = require("@material-ui/core/LinearProgress");
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress_namespaceObject);
// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit.js
var nextjs_material_kit = __webpack_require__(6547);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/customLinearProgressStyle.js

const customLinearProgressStyle = {
    root: {
        height: "4px",
        marginBottom: "20px",
        overflow: "hidden"
    },
    bar: {
        height: "4px"
    },
    primary: {
        backgroundColor: nextjs_material_kit/* primaryColor */.lr
    },
    warning: {
        backgroundColor: nextjs_material_kit/* warningColor */.MA
    },
    danger: {
        backgroundColor: nextjs_material_kit/* dangerColor */.E7
    },
    success: {
        backgroundColor: nextjs_material_kit/* successColor */.nq
    },
    info: {
        backgroundColor: nextjs_material_kit/* infoColor */.bE
    },
    rose: {
        backgroundColor: nextjs_material_kit/* roseColor */.An
    },
    gray: {
        backgroundColor: nextjs_material_kit/* grayColor */.X_
    },
    primaryBackground: {
        background: "rgba(156, 39, 176, 0.2)"
    },
    warningBackground: {
        background: "rgba(255, 152, 0, 0.2)"
    },
    dangerBackground: {
        background: "rgba(244, 67, 54, 0.2)"
    },
    successBackground: {
        background: "rgba(76, 175, 80, 0.2)"
    },
    infoBackground: {
        background: "rgba(0, 188, 212, 0.2)"
    },
    roseBackground: {
        background: "rgba(233, 30, 99, 0.2)"
    },
    grayBackground: {
        background: "rgba(221, 221, 221, 0.2)"
    }
};
/* harmony default export */ const components_customLinearProgressStyle = (customLinearProgressStyle);

;// CONCATENATED MODULE: ./components/CustomLinearProgress/CustomLinearProgress.js


// nodejs library to set properties for components

// @material-ui/core components


// core components

const CustomLinearProgress_useStyles = (0,styles_.makeStyles)(components_customLinearProgressStyle);
function CustomLinearProgress(props) {
    const classes = CustomLinearProgress_useStyles();
    const { color , ...rest } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((LinearProgress_default()), {
        ...rest,
        classes: {
            root: classes.root + " " + classes[color + "Background"],
            bar: classes.bar + " " + classes[color]
        }
    });
};
CustomLinearProgress.defaultProps = {
    color: "gray"
};
CustomLinearProgress.propTypes = {
    color: external_prop_types_default().oneOf([
        "primary",
        "warning",
        "danger",
        "success",
        "info",
        "rose",
        "gray"
    ])
};

// EXTERNAL MODULE: external "@material-ui/core/Button"
var Button_ = __webpack_require__(2610);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/paginationStyle.js

const paginationStyle = {
    pagination: {
        display: "inline-block",
        paddingLeft: "0",
        margin: "0 0 20px 0",
        borderRadius: "4px"
    },
    paginationItem: {
        display: "inline"
    },
    paginationLink: {
        ":first-of-type": {
            marginleft: "0"
        },
        letterSpacing: "unset",
        border: "0",
        borderRadius: "30px !important",
        transition: "all .3s",
        padding: "0px 11px",
        margin: "0 3px",
        minWidth: "30px",
        height: "30px",
        minHeight: "auto",
        lineHeight: "30px",
        fontWeight: "400",
        fontSize: "12px",
        textTransform: "uppercase",
        background: "transparent",
        position: "relative",
        float: "left",
        textDecoration: "none",
        boxSizing: "border-box",
        "&,&:hover,&:focus": {
            color: nextjs_material_kit/* grayColor */.X_
        },
        "&:hover,&:focus": {
            zIndex: "3",
            backgroundColor: "#eee",
            borderColor: "#ddd"
        },
        "&:hover": {
            cursor: "pointer"
        }
    },
    primary: {
        "&,&:hover,&:focus": {
            backgroundColor: nextjs_material_kit/* primaryColor */.lr,
            borderColor: nextjs_material_kit/* primaryColor */.lr,
            color: "#FFFFFF",
            boxShadow: `0 4px 5px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* primaryColor */.lr, 0.14)}, 0 1px 10px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* primaryColor */.lr, 0.12)}, 0 2px 4px -1px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* primaryColor */.lr, 0.2)}`
        },
        "&:hover,&:focus": {
            zIndex: "2",
            cursor: "default"
        }
    },
    info: {
        "&,&:hover,&:focus": {
            backgroundColor: nextjs_material_kit/* infoColor */.bE,
            borderColor: nextjs_material_kit/* infoColor */.bE,
            color: "#FFFFFF",
            boxShadow: `0 4px 5px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* infoColor */.bE, 0.14)}, 0 1px 10px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* infoColor */.bE, 0.12)}, 0 2px 4px -1px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* infoColor */.bE, 0.2)}`
        },
        "&:hover,&:focus": {
            zIndex: "2",
            cursor: "default"
        }
    },
    success: {
        "&,&:hover,&:focus": {
            backgroundColor: nextjs_material_kit/* successColor */.nq,
            borderColor: nextjs_material_kit/* successColor */.nq,
            color: "#FFFFFF",
            boxShadow: `0 4px 5px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* successColor */.nq, 0.14)}, 0 1px 10px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* successColor */.nq, 0.12)}, 0 2px 4px -1px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* successColor */.nq, 0.2)}`
        },
        "&:hover,&:focus": {
            zIndex: "2",
            cursor: "default"
        }
    },
    warning: {
        "&,&:hover,&:focus": {
            backgroundColor: nextjs_material_kit/* warningColor */.MA,
            borderColor: nextjs_material_kit/* warningColor */.MA,
            color: "#FFFFFF",
            boxShadow: `0 4px 5px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* warningColor */.MA, 0.14)}, 0 1px 10px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* warningColor */.MA, 0.12)}, 0 2px 4px -1px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* warningColor */.MA, 0.2)}`
        },
        "&:hover,&:focus": {
            zIndex: "2",
            cursor: "default"
        }
    },
    danger: {
        "&,&:hover,&:focus": {
            backgroundColor: nextjs_material_kit/* dangerColor */.E7,
            borderColor: nextjs_material_kit/* dangerColor */.E7,
            color: "#FFFFFF",
            boxShadow: `0 4px 5px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* dangerColor */.E7, 0.14)}, 0 1px 10px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* dangerColor */.E7, 0.12)}, 0 2px 4px -1px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* dangerColor */.E7, 0.2)}`
        },
        "&:hover,&:focus": {
            zIndex: "2",
            cursor: "default"
        }
    },
    rose: {
        "&,&:hover,&:focus": {
            backgroundColor: nextjs_material_kit/* roseColor */.An,
            borderColor: nextjs_material_kit/* roseColor */.An,
            color: "#FFFFFF",
            boxShadow: `0 4px 5px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* roseColor */.An, 0.14)}, 0 1px 10px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* roseColor */.An, 0.12)}, 0 2px 4px -1px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* roseColor */.An, 0.2)}`
        },
        "&:hover,&:focus": {
            zIndex: "2",
            cursor: "default"
        }
    },
    disabled: {
        "&,&:hover,&:focus": {
            color: "#777",
            cursor: "not-allowed",
            backgroundColor: "#fff",
            borderColor: "#ddd"
        }
    }
};
/* harmony default export */ const components_paginationStyle = (paginationStyle);

;// CONCATENATED MODULE: ./components/Pagination/Pagination.js


// nodejs library to set properties for components

// nodejs library that concatenates classes

// @material-ui/core components



const Pagination_useStyles = (0,styles_.makeStyles)(components_paginationStyle);
function Pagination(props) {
    const classes = Pagination_useStyles();
    const { pages , color  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: classes.pagination,
        children: pages.map((prop, key)=>{
            const paginationLink = external_classnames_default()({
                [classes.paginationLink]: true,
                [classes[color]]: prop.active,
                [classes.disabled]: prop.disabled
            });
            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: classes.paginationItem,
                children: prop.onClick !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    onClick: prop.onClick,
                    className: paginationLink,
                    children: prop.text
                }) : /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    onClick: ()=>alert("you've clicked " + prop.text),
                    className: paginationLink,
                    children: prop.text
                })
            }, key);
        })
    });
};
Pagination.defaultProps = {
    color: "primary"
};
Pagination.propTypes = {
    pages: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        active: (external_prop_types_default()).bool,
        disabled: (external_prop_types_default()).bool,
        text: external_prop_types_default().oneOfType([
            (external_prop_types_default()).number,
            external_prop_types_default().oneOf([
                "PREV",
                "NEXT",
                "..."
            ])
        ]).isRequired,
        onClick: (external_prop_types_default()).func
    })).isRequired,
    color: external_prop_types_default().oneOf([
        "primary",
        "info",
        "success",
        "warning",
        "danger"
    ])
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/badgeStyle.js

const badgeStyle = {
    badge: {
        marginRight: "3px",
        borderRadius: "12px",
        padding: "5px 12px",
        textTransform: "uppercase",
        fontSize: "10px",
        fontWeight: "500",
        lineHeight: "1",
        color: "#fff",
        textAlign: "center",
        whiteSpace: "nowrap",
        verticalAlign: "baseline",
        display: "inline-block"
    },
    primary: {
        backgroundColor: nextjs_material_kit/* primaryColor */.lr
    },
    warning: {
        backgroundColor: nextjs_material_kit/* warningColor */.MA
    },
    danger: {
        backgroundColor: nextjs_material_kit/* dangerColor */.E7
    },
    success: {
        backgroundColor: nextjs_material_kit/* successColor */.nq
    },
    info: {
        backgroundColor: nextjs_material_kit/* infoColor */.bE
    },
    rose: {
        backgroundColor: nextjs_material_kit/* roseColor */.An
    },
    gray: {
        backgroundColor: "#6c757d"
    }
};
/* harmony default export */ const components_badgeStyle = (badgeStyle);

;// CONCATENATED MODULE: ./components/Badge/Badge.js


// nodejs library to set properties for components

// @material-ui/core components


const Badge_useStyles = (0,styles_.makeStyles)(components_badgeStyle);
function Badge(props) {
    const classes = Badge_useStyles();
    const { color , children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: classes.badge + " " + classes[color],
        children: children
    });
};
Badge.defaultProps = {
    color: "gray"
};
Badge.propTypes = {
    color: external_prop_types_default().oneOf([
        "primary",
        "warning",
        "danger",
        "success",
        "info",
        "rose",
        "gray"
    ]),
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/customCheckboxRadioSwitch.js

const customCheckboxRadioSwitch = {
    checkRoot: {
        padding: "12px",
        "&:hover": {
            backgroundColor: (0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* primaryColor */.lr, 0.04) + "!important"
        }
    },
    radioRoot: {
        padding: "12px",
        "&:hover": {
            backgroundColor: (0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* primaryColor */.lr, 0.04) + "!important"
        }
    },
    labelRoot: {
        marginLeft: "-14px"
    },
    checkboxAndRadio: {
        position: "relative",
        display: "block",
        marginTop: "10px",
        marginBottom: "10px"
    },
    checkboxAndRadioHorizontal: {
        position: "relative",
        display: "block",
        "&:first-child": {
            marginTop: "10px"
        },
        "&:not(:first-child)": {
            marginTop: "-14px"
        },
        marginTop: "0",
        marginBottom: "0"
    },
    checked: {
        color: nextjs_material_kit/* primaryColor */.lr + "!important"
    },
    checkedIcon: {
        width: "20px",
        height: "20px",
        border: "1px solid rgba(0, 0, 0, .54)",
        borderRadius: "3px"
    },
    uncheckedIcon: {
        width: "0px",
        height: "0px",
        padding: "9px",
        border: "1px solid rgba(0, 0, 0, .54)",
        borderRadius: "3px"
    },
    disabledCheckboxAndRadio: {
        opacity: "0.45"
    },
    label: {
        cursor: "pointer",
        paddingLeft: "0",
        color: "rgba(0, 0, 0, 0.26)",
        fontSize: "14px",
        lineHeight: "1.428571429",
        fontWeight: "400",
        display: "inline-flex",
        transition: "0.3s ease all",
        letterSpacing: "unset"
    },
    labelHorizontal: {
        color: "rgba(0, 0, 0, 0.26)",
        cursor: "pointer",
        display: "inline-flex",
        fontSize: "14px",
        lineHeight: "1.428571429",
        fontWeight: "400",
        paddingTop: "39px",
        marginRight: "0",
        "@media (min-width: 992px)": {
            float: "right"
        }
    },
    labelHorizontalRadioCheckbox: {
        paddingTop: "22px"
    },
    labelLeftHorizontal: {
        color: "rgba(0, 0, 0, 0.26)",
        cursor: "pointer",
        display: "inline-flex",
        fontSize: "14px",
        lineHeight: "1.428571429",
        fontWeight: "400",
        paddingTop: "22px",
        marginRight: "0"
    },
    labelError: {
        color: nextjs_material_kit/* dangerColor */.E7
    },
    radio: {
        color: nextjs_material_kit/* primaryColor */.lr + "!important"
    },
    radioChecked: {
        width: "16px",
        height: "16px",
        border: "1px solid " + nextjs_material_kit/* primaryColor */.lr,
        borderRadius: "50%"
    },
    radioUnchecked: {
        width: "0px",
        height: "0px",
        padding: "7px",
        border: "1px solid rgba(0, 0, 0, .54)",
        borderRadius: "50%"
    },
    inlineChecks: {
        marginTop: "8px"
    },
    iconCheckbox: {
        height: "116px",
        width: "116px",
        color: nextjs_material_kit/* grayColor */.X_,
        "& > span:first-child": {
            borderWidth: "4px",
            borderStyle: "solid",
            borderColor: "#CCCCCC",
            textAlign: "center",
            verticalAlign: "middle",
            borderRadius: "50%",
            color: "inherit",
            margin: "0 auto 20px",
            transition: "all 0.2s"
        },
        "&:hover": {
            color: nextjs_material_kit/* roseColor */.An,
            "& > span:first-child": {
                borderColor: nextjs_material_kit/* roseColor */.An
            }
        }
    },
    iconCheckboxChecked: {
        color: nextjs_material_kit/* roseColor */.An,
        "& > span:first-child": {
            borderColor: nextjs_material_kit/* roseColor */.An
        }
    },
    iconCheckboxIcon: {
        fontSize: "40px",
        lineHeight: "111px"
    },
    switchBase: {
        color: nextjs_material_kit/* primaryColor */.lr + "!important"
    },
    switchIcon: {
        boxShadow: "0 1px 3px 1px rgba(0, 0, 0, 0.4)",
        color: "#FFFFFF !important",
        border: "1px solid rgba(0, 0, 0, .54)"
    },
    switchBar: {
        width: "30px",
        height: "15px",
        backgroundColor: "rgb(80, 80, 80)",
        borderRadius: "15px",
        opacity: "0.7!important"
    },
    switchChecked: {
        "& + $switchBar": {
            backgroundColor: "rgba(156, 39, 176, 1) !important"
        },
        "& $switchIcon": {
            borderColor: "#9c27b0"
        }
    },
    switchRoot: {
        height: "48px"
    }
};
/* harmony default export */ const nextjs_material_kit_customCheckboxRadioSwitch = (customCheckboxRadioSwitch);

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/basicsStyle.js


const basicsStyle = {
    sections: {
        padding: "70px 0"
    },
    container: nextjs_material_kit/* container */.nC,
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    space50: {
        height: "50px",
        display: "block"
    },
    space70: {
        height: "70px",
        display: "block"
    },
    icons: {
        width: "17px",
        height: "17px",
        color: "#FFFFFF"
    },
    ...nextjs_material_kit_customCheckboxRadioSwitch
};
/* harmony default export */ const componentsSections_basicsStyle = (basicsStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionBasics.js


// plugin that creates slider

// @material-ui/core components






// @material-ui/icons




// core components








const SectionBasics_useStyles = (0,styles_.makeStyles)(componentsSections_basicsStyle);
function SectionBasics() {
    const classes = SectionBasics_useStyles();
    const [checked, setChecked] = external_react_default().useState([
        24,
        22
    ]);
    const [selectedEnabled, setSelectedEnabled] = external_react_default().useState("b");
    const [checkedA, setCheckedA] = external_react_default().useState(true);
    const [checkedB, setCheckedB] = external_react_default().useState(false);
    external_react_default().useEffect(()=>{
        if (!document.getElementById("sliderRegular").classList.contains("noUi-target")) {
            external_nouislider_default().create(document.getElementById("sliderRegular"), {
                start: [
                    40
                ],
                connect: [
                    true,
                    false
                ],
                step: 1,
                range: {
                    min: 0,
                    max: 100
                }
            });
        }
        if (!document.getElementById("sliderDouble").classList.contains("noUi-target")) {
            external_nouislider_default().create(document.getElementById("sliderDouble"), {
                start: [
                    20,
                    60
                ],
                connect: [
                    false,
                    true,
                    false
                ],
                step: 1,
                range: {
                    min: 0,
                    max: 100
                }
            });
        }
        return function cleanup() {};
    });
    const handleToggle = (value)=>{
        const currentIndex = checked.indexOf(value);
        const newChecked = [
            ...checked
        ];
        if (currentIndex === -1) {
            newChecked.push(value);
        } else {
            newChecked.splice(currentIndex, 1);
        }
        setChecked(newChecked);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.sections,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: classes.container,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.title,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "Basic Elements"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "buttons",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: classes.title,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                children: [
                                    "Buttons",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                        children: "Pick your style"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 8,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        children: "Default"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        round: true,
                                        children: "round"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                        color: "primary",
                                        round: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Favorite_default()), {
                                                className: classes.icons
                                            }),
                                            " with icon"
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        justIcon: true,
                                        round: true,
                                        color: "primary",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Favorite_default()), {
                                            className: classes.icons
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        simple: true,
                                        children: "simple"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: classes.title,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                    children: "Pick your size"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 8,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        size: "sm",
                                        children: "Small"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        children: "Regular"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        size: "lg",
                                        children: "Large"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: classes.title,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                    children: "Pick your color"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 8,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        children: "Default"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        children: "Primary"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "info",
                                        children: "Info"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "success",
                                        children: "Success"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "warning",
                                        children: "Warning"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "danger",
                                        children: "Danger"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "rose",
                                        children: "Rose"
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.space50
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "inputs",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: classes.title,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "Inputs"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 4,
                                    md: 4,
                                    lg: 3,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                        id: "regular",
                                        inputProps: {
                                            placeholder: "Regular"
                                        },
                                        formControlProps: {
                                            fullWidth: true
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 4,
                                    md: 4,
                                    lg: 3,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                        labelText: "With floating label",
                                        id: "float",
                                        formControlProps: {
                                            fullWidth: true
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 4,
                                    md: 4,
                                    lg: 3,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                        labelText: "Success input",
                                        id: "success",
                                        success: true,
                                        formControlProps: {
                                            fullWidth: true
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 4,
                                    md: 4,
                                    lg: 3,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                        labelText: "Error input",
                                        id: "error",
                                        error: true,
                                        formControlProps: {
                                            fullWidth: true
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 4,
                                    md: 4,
                                    lg: 3,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                        labelText: "With material Icons",
                                        id: "material",
                                        formControlProps: {
                                            fullWidth: true
                                        },
                                        inputProps: {
                                            endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                                position: "end",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((People_default()), {})
                                            })
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 4,
                                    md: 4,
                                    lg: 3,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                        labelText: "With Font Awesome Icons",
                                        id: "font-awesome",
                                        formControlProps: {
                                            fullWidth: true
                                        },
                                        inputProps: {
                                            endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                                position: "end",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fas fa-users"
                                                })
                                            })
                                        }
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.space70
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    id: "checkRadios",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 6,
                                md: 4,
                                lg: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Checkboxes"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                tabIndex: -1,
                                                onClick: ()=>handleToggle(21),
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.checkedIcon
                                                }),
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.uncheckedIcon
                                                }),
                                                classes: {
                                                    checked: classes.checked,
                                                    root: classes.checkRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                root: classes.labelRoot
                                            },
                                            label: "Unchecked"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                tabIndex: -1,
                                                onClick: ()=>handleToggle(22),
                                                checked: checked.indexOf(22) !== -1 ? true : false,
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.checkedIcon
                                                }),
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.uncheckedIcon
                                                }),
                                                classes: {
                                                    checked: classes.checked,
                                                    root: classes.checkRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                root: classes.labelRoot
                                            },
                                            label: "Checked"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            disabled: true,
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                tabIndex: -1,
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.checkedIcon
                                                }),
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.uncheckedIcon
                                                }),
                                                classes: {
                                                    checked: classes.checked,
                                                    root: classes.checkRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                disabled: classes.disabledCheckboxAndRadio,
                                                root: classes.labelRoot
                                            },
                                            label: "Disabled Unchecked"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            disabled: true,
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                tabIndex: -1,
                                                checked: checked.indexOf(24) !== -1 ? true : false,
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.checkedIcon
                                                }),
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((Check_default()), {
                                                    className: classes.uncheckedIcon
                                                }),
                                                classes: {
                                                    checked: classes.checked,
                                                    root: classes.checkRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                disabled: classes.disabledCheckboxAndRadio,
                                                root: classes.labelRoot
                                            },
                                            label: "Disabled Checked"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 6,
                                md: 4,
                                lg: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Radio Buttons"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Radio_default()), {
                                                checked: selectedEnabled === "a",
                                                onChange: ()=>setSelectedEnabled("a"),
                                                value: "a",
                                                name: "radio button enabled",
                                                "aria-label": "A",
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioUnchecked
                                                }),
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioChecked
                                                }),
                                                classes: {
                                                    checked: classes.radio,
                                                    root: classes.radioRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                root: classes.labelRoot
                                            },
                                            label: "First Radio"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Radio_default()), {
                                                checked: selectedEnabled === "b",
                                                onChange: ()=>setSelectedEnabled("b"),
                                                value: "b",
                                                name: "radio button enabled",
                                                "aria-label": "B",
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioUnchecked
                                                }),
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioChecked
                                                }),
                                                classes: {
                                                    checked: classes.radio,
                                                    root: classes.radioRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                root: classes.labelRoot
                                            },
                                            label: "Second Radio"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            disabled: true,
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Radio_default()), {
                                                checked: false,
                                                value: "a",
                                                name: "radio button disabled",
                                                "aria-label": "B",
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioUnchecked
                                                }),
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioChecked
                                                }),
                                                classes: {
                                                    checked: classes.radio,
                                                    disabled: classes.disabledCheckboxAndRadio,
                                                    root: classes.radioRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                root: classes.labelRoot
                                            },
                                            label: "Disabled Unchecked Radio"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.checkboxAndRadio + " " + classes.checkboxAndRadioHorizontal,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            disabled: true,
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Radio_default()), {
                                                checked: true,
                                                value: "b",
                                                name: "radio button disabled",
                                                "aria-label": "B",
                                                icon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioUnchecked
                                                }),
                                                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
                                                    className: classes.radioChecked
                                                }),
                                                classes: {
                                                    checked: classes.radio,
                                                    disabled: classes.disabledCheckboxAndRadio,
                                                    root: classes.radioRoot
                                                }
                                            }),
                                            classes: {
                                                label: classes.label,
                                                root: classes.labelRoot
                                            },
                                            label: "Disabled Checked Radio"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 6,
                                md: 4,
                                lg: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Toggle Buttons"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                                checked: checkedA,
                                                onChange: (event)=>setCheckedA(event.target.checked),
                                                value: "checkedA",
                                                classes: {
                                                    switchBase: classes.switchBase,
                                                    checked: classes.switchChecked,
                                                    thumb: classes.switchIcon,
                                                    track: classes.switchBar
                                                }
                                            }),
                                            classes: {
                                                label: classes.label
                                            },
                                            label: "Toggle is on"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                                checked: checkedB,
                                                onChange: (event)=>setCheckedB(event.target.checked),
                                                value: "checkedB",
                                                classes: {
                                                    switchBase: classes.switchBase,
                                                    checked: classes.switchChecked,
                                                    thumb: classes.switchIcon,
                                                    track: classes.switchBar
                                                }
                                            }),
                                            classes: {
                                                label: classes.label
                                            },
                                            label: "Toggle is off"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.space70
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    id: "progress",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Progress Bars"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomLinearProgress, {
                                        variant: "determinate",
                                        color: "primary",
                                        value: 30
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomLinearProgress, {
                                        variant: "determinate",
                                        color: "info",
                                        value: 60
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomLinearProgress, {
                                        variant: "determinate",
                                        color: "success",
                                        value: 100,
                                        style: {
                                            width: "35%",
                                            display: "inline-block"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomLinearProgress, {
                                        variant: "determinate",
                                        color: "warning",
                                        value: 100,
                                        style: {
                                            width: "20%",
                                            display: "inline-block"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomLinearProgress, {
                                        variant: "determinate",
                                        color: "danger",
                                        value: 25,
                                        style: {
                                            width: "45%",
                                            display: "inline-block"
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Pagination"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Pagination, {
                                        pages: [
                                            {
                                                text: 1
                                            },
                                            {
                                                text: "..."
                                            },
                                            {
                                                text: 5
                                            },
                                            {
                                                text: 6
                                            },
                                            {
                                                active: true,
                                                text: 7
                                            },
                                            {
                                                text: 8
                                            },
                                            {
                                                text: 9
                                            },
                                            {
                                                text: "..."
                                            },
                                            {
                                                text: 12
                                            }
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Pagination, {
                                        pages: [
                                            {
                                                text: "PREV"
                                            },
                                            {
                                                text: 1
                                            },
                                            {
                                                text: 2
                                            },
                                            {
                                                active: true,
                                                text: 3
                                            },
                                            {
                                                text: 4
                                            },
                                            {
                                                text: 5
                                            },
                                            {
                                                text: "NEXT"
                                            }
                                        ],
                                        color: "info"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    id: "sliders",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Sliders"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        id: "sliderRegular",
                                        className: "slider-primary"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        id: "sliderDouble",
                                        className: "slider-info"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Badges"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                        children: "default"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                        color: "primary",
                                        children: "primary"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                        color: "info",
                                        children: "info"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                        color: "success",
                                        children: "success"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                        color: "warning",
                                        children: "warning"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                        color: "danger",
                                        children: "danger"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                        color: "rose",
                                        children: "rose"
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: external "@material-ui/core/List"
var List_ = __webpack_require__(5031);
var List_default = /*#__PURE__*/__webpack_require__.n(List_);
// EXTERNAL MODULE: external "@material-ui/core/ListItem"
var ListItem_ = __webpack_require__(6256);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_);
// EXTERNAL MODULE: external "@material-ui/core/Icon"
var Icon_ = __webpack_require__(7886);
var Icon_default = /*#__PURE__*/__webpack_require__.n(Icon_);
;// CONCATENATED MODULE: external "@material-ui/icons/Search"
const Search_namespaceObject = require("@material-ui/icons/Search");
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/Email"
const Email_namespaceObject = require("@material-ui/icons/Email");
var Email_default = /*#__PURE__*/__webpack_require__.n(Email_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/Face"
const Face_namespaceObject = require("@material-ui/icons/Face");
var Face_default = /*#__PURE__*/__webpack_require__.n(Face_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/AccountCircle"
const AccountCircle_namespaceObject = require("@material-ui/icons/AccountCircle");
var AccountCircle_default = /*#__PURE__*/__webpack_require__.n(AccountCircle_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/Explore"
const Explore_namespaceObject = require("@material-ui/icons/Explore");
var Explore_default = /*#__PURE__*/__webpack_require__.n(Explore_namespaceObject);
// EXTERNAL MODULE: ./components/CustomDropdown/CustomDropdown.js + 1 modules
var CustomDropdown = __webpack_require__(3743);
// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit/components/headerLinksStyle.js
var headerLinksStyle = __webpack_require__(9441);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/navbarsStyle.js


const navbarsStyle = (theme)=>({
        section: {
            padding: "70px 0",
            paddingTop: "0"
        },
        container: nextjs_material_kit/* container */.nC,
        title: {
            ...nextjs_material_kit/* title */.TN,
            marginTop: "30px",
            minHeight: "32px",
            textDecoration: "none"
        },
        navbar: {
            marginBottom: "-20px",
            zIndex: "100",
            position: "relative",
            overflow: "hidden",
            "& header": {
                borderRadius: "0"
            }
        },
        navigation: {
            backgroundPosition: "center center",
            backgroundSize: "cover",
            marginTop: "0",
            minHeight: "740px"
        },
        formControl: {
            [theme.breakpoints.down("md")]: {
                margin: "10px 0 0 15px !important",
                color: nextjs_material_kit/* grayColor */.X_
            },
            margin: "10px 0 0 0 !important",
            paddingTop: "0"
        },
        inputRootCustomClasses: {
            margin: "0!important"
        },
        searchIcon: {
            width: "20px",
            height: "20px",
            color: "inherit"
        },
        ...(0,headerLinksStyle/* default */.Z)(theme),
        img: {
            width: "40px",
            height: "40px",
            borderRadius: "50%"
        },
        imageDropdownButton: {
            [theme.breakpoints.down("md")]: {
                top: "0",
                margin: "5px 15px"
            },
            padding: "0px",
            top: "4px",
            borderRadius: "50%",
            marginLeft: "5px"
        }
    });
/* harmony default export */ const componentsSections_navbarsStyle = (navbarsStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionNavbars.js


// @material-ui/core components




// @material-ui/icons





// core components







const SectionNavbars_useStyles = (0,styles_.makeStyles)(componentsSections_navbarsStyle);
function SectionNavbars() {
    const classes = SectionNavbars_useStyles();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: classes.section,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: classes.container,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Menu"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                                        brand: "Menu",
                                        color: "primary",
                                        leftLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                            className: classes.list,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                                    className: classes.listItem,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                        href: "#pablo",
                                                        className: classes.navLink,
                                                        onClick: (e)=>e.preventDefault(),
                                                        color: "transparent",
                                                        children: "Link"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                                    className: classes.listItem,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                        href: "#pablo",
                                                        className: classes.navLink,
                                                        onClick: (e)=>e.preventDefault(),
                                                        color: "transparent",
                                                        children: "Link"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                                    className: classes.listItem,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomDropdown/* default */.Z, {
                                                        navDropdown: true,
                                                        buttonText: "Dropdown",
                                                        dropdownHeader: "Dropdown Header",
                                                        buttonProps: {
                                                            className: classes.navLink,
                                                            color: "transparent"
                                                        },
                                                        dropdownList: [
                                                            "Action",
                                                            "Another action",
                                                            "Something else here",
                                                            {
                                                                divider: true
                                                            },
                                                            "Separated link",
                                                            {
                                                                divider: true
                                                            },
                                                            "One more separated link"
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: classes.title,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Menu with Icons"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                                        brand: "Icons",
                                        color: "info",
                                        rightLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                            className: classes.list,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                                    className: classes.listItem,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                        color: "transparent",
                                                        className: classes.navLink,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Email_default()), {
                                                            className: classes.icons
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                                    className: classes.listItem,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                        color: "transparent",
                                                        className: classes.navLink,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Face_default()), {
                                                            className: classes.icons
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                                    className: classes.listItem,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomDropdown/* default */.Z, {
                                                        left: true,
                                                        navDropdown: true,
                                                        hoverColor: "info",
                                                        dropdownHeader: "Dropdown Header",
                                                        buttonIcon: "settings",
                                                        buttonProps: {
                                                            className: classes.navLink,
                                                            color: "transparent"
                                                        },
                                                        dropdownList: [
                                                            "Action",
                                                            "Another action",
                                                            "Something else here",
                                                            {
                                                                divider: true
                                                            },
                                                            "Separated link",
                                                            {
                                                                divider: true
                                                            },
                                                            "One more separated link"
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: classes.title,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: "Navigation"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "navbar",
                className: classes.navbar,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: classes.navigation,
                    style: {
                        backgroundImage: "url('/img/bg.jpg')"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                            brand: "Brand",
                            color: "rose",
                            leftLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                className: classes.list,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Link"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Link"
                                        })
                                    })
                                ]
                            }),
                            rightLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                        white: true,
                                        inputRootCustomClasses: classes.inputRootCustomClasses,
                                        formControlProps: {
                                            className: classes.formControl
                                        },
                                        inputProps: {
                                            placeholder: "Search",
                                            inputProps: {
                                                "aria-label": "Search",
                                                className: classes.searchInput
                                            }
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        justIcon: true,
                                        round: true,
                                        color: "white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {
                                            className: classes.searchIcon
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                            brand: "Info Color",
                            color: "info",
                            rightLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                className: classes.list,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink + " " + classes.navLinkActive,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Discover"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Profile"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Settings"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                            brand: "Primary Color",
                            color: "primary",
                            rightLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                className: classes.list,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink + " " + classes.navLinkActive,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Explore_default()), {
                                                    className: classes.icons
                                                }),
                                                " Discover"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((AccountCircle_default()), {
                                                    className: classes.icons
                                                }),
                                                " Profile"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Icon_default()), {
                                                    className: classes.icons,
                                                    children: "settings"
                                                }),
                                                " Settings"
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                            brand: "Navbar with notifications",
                            color: "dark",
                            rightLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                className: classes.list,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Discover"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Wishlist"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            justIcon: true,
                                            round: true,
                                            href: "#pablo",
                                            className: classes.notificationNavLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "rose",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Email_default()), {
                                                className: classes.icons
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(CustomDropdown/* default */.Z, {
                                            left: true,
                                            caret: false,
                                            hoverColor: "black",
                                            dropdownHeader: "Dropdown Header",
                                            buttonText: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/img/faces/avatar.jpg",
                                                className: classes.img,
                                                alt: "profile"
                                            }),
                                            buttonProps: {
                                                className: classes.navLink + " " + classes.imageDropdownButton,
                                                color: "transparent"
                                            },
                                            dropdownList: [
                                                "Me",
                                                "Settings and other stuff",
                                                "Sign out"
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                            brand: "Navbar with profile",
                            rightLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                className: classes.list,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Discover"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.navLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "transparent",
                                            children: "Wishlist"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                            href: "#pablo",
                                            className: classes.registerNavLink,
                                            onClick: (e)=>e.preventDefault(),
                                            color: "rose",
                                            round: true,
                                            children: "Register"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                            brand: "Transparent",
                            color: "transparent",
                            rightLinks: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                className: classes.list,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                            color: "transparent",
                                            className: classes.navLink + " " + classes.socialIconsButton,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: classes.socialIcons + " " + classes.marginRight5 + " fab fa-twitter"
                                                }),
                                                " ",
                                                "Twitter"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                            color: "transparent",
                                            className: classes.navLink + " " + classes.socialIconsButton,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: classes.socialIcons + " " + classes.marginRight5 + " fab fa-facebook"
                                                }),
                                                " ",
                                                "Facebook"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        className: classes.listItem,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                            color: "transparent",
                                            className: classes.navLink + " " + classes.socialIconsButton,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: classes.socialIcons + " " + classes.marginRight5 + " fab fa-instagram"
                                                }),
                                                " ",
                                                "Instagram"
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

// EXTERNAL MODULE: external "@material-ui/icons/Chat"
var Chat_ = __webpack_require__(1677);
var Chat_default = /*#__PURE__*/__webpack_require__.n(Chat_);
;// CONCATENATED MODULE: external "@material-ui/icons/Build"
const Build_namespaceObject = require("@material-ui/icons/Build");
var Build_default = /*#__PURE__*/__webpack_require__.n(Build_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/Tabs"
const Tabs_namespaceObject = require("@material-ui/core/Tabs");
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/Tab"
const Tab_namespaceObject = require("@material-ui/core/Tab");
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab_namespaceObject);
// EXTERNAL MODULE: ./components/Card/Card.js + 1 modules
var Card = __webpack_require__(2406);
// EXTERNAL MODULE: ./components/Card/CardBody.js + 1 modules
var CardBody = __webpack_require__(7585);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/cardHeaderStyle.js

const cardHeaderStyle = {
    cardHeader: {
        borderRadius: "3px",
        padding: "1rem 15px",
        marginLeft: "15px",
        marginRight: "15px",
        marginTop: "-30px",
        border: "0",
        marginBottom: "0"
    },
    cardHeaderPlain: {
        marginLeft: "0px",
        marginRight: "0px"
    },
    warningCardHeader: nextjs_material_kit/* warningCardHeader */.rt,
    successCardHeader: nextjs_material_kit/* successCardHeader */.aT,
    dangerCardHeader: nextjs_material_kit/* dangerCardHeader */.yF,
    infoCardHeader: nextjs_material_kit/* infoCardHeader */.Yi,
    primaryCardHeader: nextjs_material_kit/* primaryCardHeader */.hF
};
/* harmony default export */ const components_cardHeaderStyle = (cardHeaderStyle);

;// CONCATENATED MODULE: ./components/Card/CardHeader.js


// nodejs library that concatenates classes

// nodejs library to set properties for components

// @material-ui/core components

// @material-ui/icons
// core components

const CardHeader_useStyles = (0,styles_.makeStyles)(components_cardHeaderStyle);
function CardHeader(props) {
    const classes = CardHeader_useStyles();
    const { className , children , color , plain , ...rest } = props;
    const cardHeaderClasses = external_classnames_default()({
        [classes.cardHeader]: true,
        [classes[color + "CardHeader"]]: color,
        [classes.cardHeaderPlain]: plain,
        [className]: className !== undefined
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: cardHeaderClasses,
        ...rest,
        children: children
    });
};
CardHeader.propTypes = {
    className: (external_prop_types_default()).string,
    color: external_prop_types_default().oneOf([
        "warning",
        "success",
        "danger",
        "info",
        "primary"
    ]),
    plain: (external_prop_types_default()).bool,
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/customTabsStyle.js
const customTabsStyle = {
    cardTitle: {
        float: "left",
        padding: "10px 10px 10px 0px",
        lineHeight: "24px"
    },
    cardTitleRTL: {
        float: "right",
        padding: "10px 0px 10px 10px !important"
    },
    displayNone: {
        display: "none !important"
    },
    tabsRoot: {
        minHeight: "unset !important"
    },
    tabRootButton: {
        minHeight: "unset !important",
        minWidth: "unset !important",
        width: "unset !important",
        height: "unset !important",
        maxWidth: "unset !important",
        maxHeight: "unset !important",
        padding: "10px 15px",
        borderRadius: "3px",
        lineHeight: "24px",
        border: "0 !important",
        color: "#fff !important",
        marginLeft: "4px",
        fontWeight: "500",
        fontSize: "12px",
        "&:last-child": {
            marginLeft: "0px"
        }
    },
    tabSelected: {
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        transition: "0.2s background-color 0.1s"
    },
    tabWrapper: {
        display: "inline-block",
        minHeight: "unset !important",
        minWidth: "unset !important",
        width: "unset !important",
        height: "unset !important",
        maxWidth: "unset !important",
        maxHeight: "unset !important",
        "& > svg": {
            verticalAlign: "middle",
            margin: "-1.55px 5px 0 0 !important"
        },
        "&,& *": {
            letterSpacing: "normal !important"
        }
    }
};
/* harmony default export */ const components_customTabsStyle = (customTabsStyle);

;// CONCATENATED MODULE: ./components/CustomTabs/CustomTabs.js


// nodejs library that concatenates classes

// nodejs library to set properties for components

// material-ui components




// core components




const CustomTabs_useStyles = (0,styles_.makeStyles)(components_customTabsStyle);
function CustomTabs(props) {
    const [value, setValue] = external_react_default().useState(0);
    const handleChange = (event, value)=>{
        setValue(value);
    };
    const classes = CustomTabs_useStyles();
    const { headerColor , plainTabs , tabs , title , rtlActive  } = props;
    const cardTitle = external_classnames_default()({
        [classes.cardTitle]: true,
        [classes.cardTitleRTL]: rtlActive
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card/* default */.Z, {
        plain: plainTabs,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardHeader, {
                color: headerColor,
                plain: plainTabs,
                children: [
                    title !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: cardTitle,
                        children: title
                    }) : null,
                    /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
                        value: value,
                        onChange: handleChange,
                        classes: {
                            root: classes.tabsRoot,
                            indicator: classes.displayNone
                        },
                        children: tabs.map((prop, key)=>{
                            var icon = {};
                            if (prop.tabIcon) {
                                icon = {
                                    icon: typeof prop.tabIcon === "string" ? /*#__PURE__*/ jsx_runtime_.jsx((Icon_default()), {
                                        children: prop.tabIcon
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(prop.tabIcon, {})
                                };
                            }
                            return /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                                classes: {
                                    root: classes.tabRootButton,
                                    label: classes.tabLabel,
                                    selected: classes.tabSelected,
                                    wrapper: classes.tabWrapper
                                },
                                label: prop.tabName,
                                ...icon
                            }, key);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CardBody/* default */.Z, {
                children: tabs.map((prop, key)=>{
                    if (key === value) {
                        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: prop.tabContent
                        }, key);
                    }
                    return null;
                })
            })
        ]
    });
};
CustomTabs.propTypes = {
    headerColor: external_prop_types_default().oneOf([
        "warning",
        "success",
        "danger",
        "info",
        "primary",
        "rose"
    ]),
    title: (external_prop_types_default()).string,
    tabs: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        tabName: (external_prop_types_default()).string.isRequired,
        tabIcon: (external_prop_types_default()).object,
        tabContent: (external_prop_types_default()).node.isRequired
    })),
    rtlActive: (external_prop_types_default()).bool,
    plainTabs: (external_prop_types_default()).bool
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/tabsStyle.js

const tabsStyle = {
    section: {
        background: "#EEEEEE",
        padding: "70px 0"
    },
    container: nextjs_material_kit/* container */.nC,
    textCenter: {
        textAlign: "center"
    }
};
/* harmony default export */ const componentsSections_tabsStyle = (tabsStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionTabs.js


// @material-ui/core components

// @material-ui/icons



// core components




const SectionTabs_useStyles = (0,styles_.makeStyles)(componentsSections_tabsStyle);
function SectionTabs() {
    const classes = SectionTabs_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: classes.container,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "nav-tabs",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Navigation Tabs"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                            children: "Tabs with Icons on Card"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomTabs, {
                                        headerColor: "primary",
                                        tabs: [
                                            {
                                                tabName: "Profile",
                                                tabIcon: (Face_default()),
                                                tabContent: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: classes.textCenter,
                                                    children: "I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at. So when you get something that has the name Kanye West on it, it’s supposed to be pushing the furthest possibilities. I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus."
                                                })
                                            },
                                            {
                                                tabName: "Messages",
                                                tabIcon: (Chat_default()),
                                                tabContent: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: classes.textCenter,
                                                    children: "I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at. I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at."
                                                })
                                            },
                                            {
                                                tabName: "Settings",
                                                tabIcon: (Build_default()),
                                                tabContent: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: classes.textCenter,
                                                    children: "think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at. So when you get something that has the name Kanye West on it, it’s supposed to be pushing the furthest possibilities. I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus."
                                                })
                                            }
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                            children: "Tabs on Plain Card"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(CustomTabs, {
                                        plainTabs: true,
                                        headerColor: "danger",
                                        tabs: [
                                            {
                                                tabName: "Home",
                                                tabContent: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: classes.textCenter,
                                                    children: "I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at. So when you get something that has the name Kanye West on it, it’s supposed to be pushing the furthest possibilities. I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus."
                                                })
                                            },
                                            {
                                                tabName: "Updates",
                                                tabContent: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: classes.textCenter,
                                                    children: "I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at. I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at."
                                                })
                                            },
                                            {
                                                tabName: "History",
                                                tabContent: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: classes.textCenter,
                                                    children: "think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at. So when you get something that has the name Kanye West on it, it’s supposed to be pushing the furthest possibilities. I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus."
                                                })
                                            }
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: external "@material-ui/icons/Dashboard"
const Dashboard_namespaceObject = require("@material-ui/icons/Dashboard");
var Dashboard_default = /*#__PURE__*/__webpack_require__.n(Dashboard_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/Schedule"
const Schedule_namespaceObject = require("@material-ui/icons/Schedule");
var Schedule_default = /*#__PURE__*/__webpack_require__.n(Schedule_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/List"
const icons_List_namespaceObject = require("@material-ui/icons/List");
var icons_List_default = /*#__PURE__*/__webpack_require__.n(icons_List_namespaceObject);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/navPillsStyle.js

const navPillsStyle = (theme)=>({
        root: {
            marginTop: "20px",
            paddingLeft: "0",
            marginBottom: "0",
            overflow: "visible !important",
            lineHeight: "24px",
            textTransform: "uppercase",
            fontSize: "12px",
            fontWeight: "500",
            position: "relative",
            display: "block",
            color: "inherit"
        },
        flexContainer: {
            [theme.breakpoints.down("xs")]: {
                display: "flex",
                flexWrap: "wrap"
            }
        },
        displayNone: {
            display: "none !important"
        },
        fixed: {
            overflow: "visible !important"
        },
        horizontalDisplay: {
            display: "block"
        },
        pills: {
            float: "left",
            position: "relative",
            display: "block",
            borderRadius: "30px",
            minWidth: "100px",
            textAlign: "center",
            transition: "all .3s",
            padding: "10px 15px",
            color: "#555555",
            height: "auto",
            opacity: "1",
            maxWidth: "100%",
            margin: "0 5px"
        },
        pillsWithIcons: {
            borderRadius: "4px"
        },
        tabIcon: {
            width: "30px",
            height: "30px",
            display: "block",
            margin: "15px 0 !important",
            "&, & *": {
                letterSpacing: "normal !important"
            }
        },
        horizontalPills: {
            width: "100%",
            float: "none !important",
            "& + button": {
                margin: "10px 0"
            }
        },
        contentWrapper: {
            marginTop: "20px"
        },
        primary: {
            "&,&:hover": {
                color: "#FFFFFF",
                backgroundColor: nextjs_material_kit/* primaryColor */.lr,
                boxShadow: `0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* primaryColor */.lr, 0.4)}`
            }
        },
        info: {
            "&,&:hover": {
                color: "#FFFFFF",
                backgroundColor: nextjs_material_kit/* infoColor */.bE,
                boxShadow: `0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* infoColor */.bE, 0.4)}`
            }
        },
        success: {
            "&,&:hover": {
                color: "#FFFFFF",
                backgroundColor: nextjs_material_kit/* successColor */.nq,
                boxShadow: `0 2px 2px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* successColor */.nq, 0.14)}, 0 3px 1px -2px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* successColor */.nq, 0.2)}, 0 1px 5px 0 ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* successColor */.nq, 0.12)}`
            }
        },
        warning: {
            "&,&:hover": {
                color: "#FFFFFF",
                backgroundColor: nextjs_material_kit/* warningColor */.MA,
                boxShadow: `0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* warningColor */.MA, 0.4)}`
            }
        },
        danger: {
            "&,&:hover": {
                color: "#FFFFFF",
                backgroundColor: nextjs_material_kit/* dangerColor */.E7,
                boxShadow: `0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* dangerColor */.E7, 0.4)}`
            }
        },
        rose: {
            "&,&:hover": {
                color: "#FFFFFF",
                backgroundColor: nextjs_material_kit/* roseColor */.An,
                boxShadow: `0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px ${(0,nextjs_material_kit/* hexToRGBAlpha */.vS)(nextjs_material_kit/* roseColor */.An, 0.4)}`
            }
        },
        alignCenter: {
            alignItems: "center",
            justifyContent: "center"
        },
        tabWrapper: {
            color: "inherit",
            position: "relative",
            fontSize: "12px",
            lineHeight: "24px",
            fontWeight: "500",
            textTransform: "uppercase",
            "&,& *": {
                letterSpacing: "normal"
            }
        }
    });
/* harmony default export */ const components_navPillsStyle = (navPillsStyle);

;// CONCATENATED MODULE: ./components/NavPills/NavPills.js


// nodejs library that concatenates classes

// nodejs library to set properties for components

// @material-ui/core components



// core components



const NavPills_useStyles = (0,styles_.makeStyles)(components_navPillsStyle);
function NavPills(props) {
    const [active, setActive] = external_react_default().useState(props.active);
    const handleChange = (event, active)=>{
        setActive(active);
    };
    const handleChangeIndex = (index)=>{
        setActive(index);
    };
    const classes = NavPills_useStyles();
    const { tabs , color , horizontal , alignCenter  } = props;
    const flexContainerClasses = external_classnames_default()({
        [classes.flexContainer]: true,
        [classes.horizontalDisplay]: horizontal !== undefined
    });
    const tabButtons = /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
        classes: {
            root: classes.root,
            fixed: classes.fixed,
            flexContainer: flexContainerClasses,
            indicator: classes.displayNone
        },
        value: active,
        onChange: handleChange,
        centered: alignCenter,
        children: tabs.map((prop, key)=>{
            var icon = {};
            if (prop.tabIcon !== undefined) {
                icon["icon"] = /*#__PURE__*/ jsx_runtime_.jsx(prop.tabIcon, {
                    className: classes.tabIcon
                });
            }
            const pillsClasses = external_classnames_default()({
                [classes.pills]: true,
                [classes.horizontalPills]: horizontal !== undefined,
                [classes.pillsWithIcons]: prop.tabIcon !== undefined
            });
            return /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                label: prop.tabButton,
                ...icon,
                classes: {
                    root: pillsClasses,
                    selected: classes[color],
                    wrapper: classes.tabWrapper
                }
            }, key);
        })
    });
    const tabContent = /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.contentWrapper,
        children: tabs.map((prop, key)=>{
            if (key !== active) {
                return null;
            } else {
                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.tabContent,
                    children: prop.tabContent
                }, key);
            }
        })
    });
    return horizontal !== undefined ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                ...horizontal.tabsGrid,
                children: tabButtons
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                ...horizontal.contentGrid,
                children: tabContent
            })
        ]
    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            tabButtons,
            tabContent
        ]
    });
};
NavPills.defaultProps = {
    active: 0,
    color: "primary"
};
NavPills.propTypes = {
    // index of the default active pill
    active: (external_prop_types_default()).number,
    tabs: external_prop_types_default().arrayOf(external_prop_types_default().shape({
        tabButton: (external_prop_types_default()).string,
        tabIcon: (external_prop_types_default()).object,
        tabContent: (external_prop_types_default()).node
    })).isRequired,
    color: external_prop_types_default().oneOf([
        "primary",
        "warning",
        "danger",
        "success",
        "info",
        "rose"
    ]),
    horizontal: external_prop_types_default().shape({
        tabsGrid: (external_prop_types_default()).object,
        contentGrid: (external_prop_types_default()).object
    }),
    alignCenter: (external_prop_types_default()).bool
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/pillsStyle.js

const pillsStyle = {
    section: {
        padding: "70px 0"
    },
    container: nextjs_material_kit/* container */.nC,
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    }
};
/* harmony default export */ const componentsSections_pillsStyle = (pillsStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionPills.js


// @material-ui/core components

// @material-ui/icons



// core components




const SectionPills_useStyles = (0,styles_.makeStyles)(componentsSections_pillsStyle);
function SectionPills() {
    const classes = SectionPills_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: classes.container,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "navigation-pills",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: classes.title,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: "Navigation Pills"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: classes.title,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                children: "With Icons"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 8,
                                lg: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(NavPills, {
                                    color: "primary",
                                    tabs: [
                                        {
                                            tabButton: "Dashboard",
                                            tabIcon: (Dashboard_default()),
                                            tabContent: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    })
                                                ]
                                            })
                                        },
                                        {
                                            tabButton: "Schedule",
                                            tabIcon: (Schedule_default()),
                                            tabContent: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically maintain clicks-and-mortar solutions without functional solutions. Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    })
                                                ]
                                            })
                                        },
                                        {
                                            tabButton: "Tasks",
                                            tabIcon: (icons_List_default()),
                                            tabContent: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    })
                                                ]
                                            })
                                        }
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                                xs: 12,
                                sm: 12,
                                md: 12,
                                lg: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(NavPills, {
                                    color: "rose",
                                    horizontal: {
                                        tabsGrid: {
                                            xs: 12,
                                            sm: 4,
                                            md: 4
                                        },
                                        contentGrid: {
                                            xs: 12,
                                            sm: 8,
                                            md: 8
                                        }
                                    },
                                    tabs: [
                                        {
                                            tabButton: "Dashboard",
                                            tabIcon: (Dashboard_default()),
                                            tabContent: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    })
                                                ]
                                            })
                                        },
                                        {
                                            tabButton: "Schedule",
                                            tabIcon: (Schedule_default()),
                                            tabContent: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Dramatically maintain clicks-and-mortar solutions without functional solutions. Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits."
                                                    })
                                                ]
                                            })
                                        }
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: external "@material-ui/icons/Warning"
const Warning_namespaceObject = require("@material-ui/icons/Warning");
var Warning_default = /*#__PURE__*/__webpack_require__.n(Warning_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/SnackbarContent"
const SnackbarContent_namespaceObject = require("@material-ui/core/SnackbarContent");
var SnackbarContent_default = /*#__PURE__*/__webpack_require__.n(SnackbarContent_namespaceObject);
// EXTERNAL MODULE: external "@material-ui/core/IconButton"
var IconButton_ = __webpack_require__(3974);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
;// CONCATENATED MODULE: external "@material-ui/icons/Close"
const Close_namespaceObject = require("@material-ui/icons/Close");
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_namespaceObject);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/snackbarContentStyle.js

const snackbarContentStyle = {
    root: {
        ...nextjs_material_kit/* defaultFont */.Df,
        position: "relative",
        padding: "20px 15px",
        lineHeight: "20px",
        marginBottom: "20px",
        fontSize: "14px",
        backgroundColor: "white",
        color: "#555555",
        borderRadius: "0px",
        maxWidth: "100%",
        minWidth: "auto",
        boxShadow: "0 12px 20px -10px rgba(255, 255, 255, 0.28), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(255, 255, 255, 0.2)"
    },
    info: {
        backgroundColor: "#00d3ee",
        color: "#ffffff",
        ...nextjs_material_kit/* infoBoxShadow */.ur
    },
    success: {
        backgroundColor: "#5cb860",
        color: "#ffffff",
        ...nextjs_material_kit/* successBoxShadow */.TI
    },
    warning: {
        backgroundColor: "#ffa21a",
        color: "#ffffff",
        ...nextjs_material_kit/* warningBoxShadow */.D6
    },
    danger: {
        backgroundColor: "#f55a4e",
        color: "#ffffff",
        ...nextjs_material_kit/* dangerBoxShadow */.iW
    },
    primary: {
        backgroundColor: "#af2cc5",
        color: "#ffffff",
        ...nextjs_material_kit/* primaryBoxShadow */.kY
    },
    message: {
        padding: "0",
        display: "block",
        maxWidth: "89%",
        "&,& *": {
            letterSpacing: "normal"
        }
    },
    close: {
        width: "14px",
        height: "14px"
    },
    iconButton: {
        width: "24px",
        height: "24px",
        float: "right",
        fontSize: "1.5rem",
        fontWeight: "500",
        lineHeight: "1",
        position: "absolute",
        right: "-4px",
        top: "0",
        padding: "0"
    },
    icon: {
        display: "block",
        float: "left",
        marginRight: "1.071rem"
    },
    container: {
        ...nextjs_material_kit/* container */.nC,
        position: "relative"
    }
};
/* harmony default export */ const components_snackbarContentStyle = (snackbarContentStyle);

;// CONCATENATED MODULE: ./components/Snackbar/SnackbarContent.js


// nodejs library to set properties for components

// @material-ui/core components




// @material-ui/icons

// core components

const SnackbarContent_useStyles = (0,styles_.makeStyles)(components_snackbarContentStyle);
function SnackbarContent(props) {
    const { message , color , close , icon  } = props;
    const classes = SnackbarContent_useStyles();
    var action = [];
    const closeAlert = ()=>{
        setAlert(null);
    };
    if (close !== undefined) {
        action = [
            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                className: classes.iconButton,
                "aria-label": "Close",
                color: "inherit",
                onClick: closeAlert,
                children: /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                    className: classes.close
                })
            }, "close")
        ];
    }
    let snackIcon = null;
    switch(typeof icon){
        case "object":
            snackIcon = /*#__PURE__*/ jsx_runtime_.jsx(props.icon, {
                className: classes.icon
            });
            break;
        case "string":
            snackIcon = /*#__PURE__*/ jsx_runtime_.jsx((Icon_default()), {
                className: classes.icon,
                children: props.icon
            });
            break;
        default:
            snackIcon = null;
            break;
    }
    const [alert, setAlert] = external_react_default().useState(/*#__PURE__*/ jsx_runtime_.jsx((SnackbarContent_default()), {
        message: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                snackIcon,
                message,
                close !== undefined ? action : null
            ]
        }),
        classes: {
            root: classes.root + " " + classes[color],
            message: classes.message + " " + classes.container
        }
    }));
    return alert;
};
SnackbarContent.propTypes = {
    message: (external_prop_types_default()).node.isRequired,
    color: external_prop_types_default().oneOf([
        "info",
        "success",
        "warning",
        "danger",
        "primary"
    ]),
    close: (external_prop_types_default()).bool,
    icon: external_prop_types_default().oneOfType([
        (external_prop_types_default()).object,
        (external_prop_types_default()).string
    ])
};

;// CONCATENATED MODULE: ./components/Clearfix/Clearfix.js


// mterial-ui components

const styles = {
    clearfix: {
        "&:after,&:before": {
            display: "table",
            content: '" "'
        },
        "&:after": {
            clear: "both"
        }
    }
};
const Clearfix_useStyles = (0,styles_.makeStyles)(styles);
function Clearfix() {
    const classes = Clearfix_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.clearfix
    });
};
Clearfix.propTypes = {};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/notificationsStyles.js

const notificationsStyles = {
    section: {
        backgroundColor: "#FFFFFF",
        display: "block",
        width: "100%",
        position: "relative",
        padding: "0"
    },
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    container: nextjs_material_kit/* container */.nC
};
/* harmony default export */ const componentsSections_notificationsStyles = (notificationsStyles);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionNotifications.js


// @material-ui/core components

// @material-ui/icons


// core components



const SectionNotifications_useStyles = (0,styles_.makeStyles)(componentsSections_notificationsStyles);
function SectionNotifications() {
    const classes = SectionNotifications_useStyles();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: classes.section,
        id: "notifications",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: classes.container,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.title,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Notifications"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SnackbarContent, {
                message: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: "INFO ALERT:"
                        }),
                        " You",
                        "'",
                        "ve got some friends nearby, stop looking at your phone and find them..."
                    ]
                }),
                close: true,
                color: "info",
                icon: "info_outline"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SnackbarContent, {
                message: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: "SUCCESS ALERT:"
                        }),
                        " You",
                        "'",
                        "ve got some friends nearby, stop looking at your phone and find them..."
                    ]
                }),
                close: true,
                color: "success",
                icon: (Check_default())
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SnackbarContent, {
                message: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: "WARNING ALERT:"
                        }),
                        " You",
                        "'",
                        "ve got some friends nearby, stop looking at your phone and find them..."
                    ]
                }),
                close: true,
                color: "warning",
                icon: (Warning_default())
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SnackbarContent, {
                message: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: "DANGER ALERT:"
                        }),
                        " You",
                        "'",
                        "ve got some friends nearby, stop looking at your phone and find them..."
                    ]
                }),
                close: true,
                color: "danger",
                icon: "info_outline"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Clearfix, {})
        ]
    });
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/typographyStyle.js

const typographyStyle = {
    defaultFontStyle: {
        ...nextjs_material_kit/* defaultFont */.Df,
        fontSize: "14px"
    },
    defaultHeaderMargins: {
        marginTop: "20px",
        marginBottom: "10px"
    },
    quote: {
        padding: "10px 20px",
        margin: "0 0 20px",
        fontSize: "17.5px",
        borderLeft: "5px solid #eee"
    },
    quoteText: {
        margin: "0 0 10px",
        fontStyle: "italic"
    },
    quoteAuthor: {
        display: "block",
        fontSize: "80%",
        lineHeight: "1.42857143",
        color: "#777"
    },
    mutedText: {
        color: "#777"
    },
    primaryText: {
        color: nextjs_material_kit/* primaryColor */.lr
    },
    infoText: {
        color: nextjs_material_kit/* infoColor */.bE
    },
    successText: {
        color: nextjs_material_kit/* successColor */.nq
    },
    warningText: {
        color: nextjs_material_kit/* warningColor */.MA
    },
    dangerText: {
        color: nextjs_material_kit/* dangerColor */.E7
    },
    smallText: {
        fontSize: "65%",
        fontWeight: "400",
        lineHeight: "1",
        color: "#777"
    }
};
/* harmony default export */ const components_typographyStyle = (typographyStyle);

;// CONCATENATED MODULE: ./components/Typography/Small.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Small_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Small(props) {
    const classes = Small_useStyles();
    const { children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.defaultFontStyle + " " + classes.smallText,
        children: children
    });
};
Small.propTypes = {
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./components/Typography/Danger.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Danger_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Danger(props) {
    const classes = Danger_useStyles();
    const { children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.defaultFontStyle + " " + classes.dangerText,
        children: children
    });
};
Danger.propTypes = {
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./components/Typography/Warning.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Warning_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Warning(props) {
    const classes = Warning_useStyles();
    const { children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.defaultFontStyle + " " + classes.warningText,
        children: children
    });
};
Warning.propTypes = {
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./components/Typography/Success.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Success_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Success(props) {
    const classes = Success_useStyles();
    const { children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.defaultFontStyle + " " + classes.successText,
        children: children
    });
};
Success.propTypes = {
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./components/Typography/Info.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Info_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Info(props) {
    const classes = Info_useStyles();
    const { children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.defaultFontStyle + " " + classes.infoText,
        children: children
    });
};
Info.propTypes = {
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./components/Typography/Primary.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Primary_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Primary(props) {
    const classes = Primary_useStyles();
    const { children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.defaultFontStyle + " " + classes.primaryText,
        children: children
    });
};
Primary.propTypes = {
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./components/Typography/Muted.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Muted_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Muted(props) {
    const classes = Muted_useStyles();
    const { children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.defaultFontStyle + " " + classes.mutedText,
        children: children
    });
};
Muted.propTypes = {
    children: (external_prop_types_default()).node
};

;// CONCATENATED MODULE: ./components/Typography/Quote.js


// nodejs library to set properties for components

// @material-ui/core components

// core components

const Quote_useStyles = (0,styles_.makeStyles)(components_typographyStyle);
function Quote(props) {
    const { text , author  } = props;
    const classes = Quote_useStyles();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("blockquote", {
        className: classes.defaultFontStyle + " " + classes.quote,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: classes.quoteText,
                children: text
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                className: classes.quoteAuthor,
                children: author
            })
        ]
    });
};
Quote.propTypes = {
    text: (external_prop_types_default()).node,
    author: (external_prop_types_default()).node
};

// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit/imagesStyles.js
var imagesStyles = __webpack_require__(266);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/typographyStyle.js


const typographyStyle_typographyStyle = {
    section: {
        padding: "70px 0"
    },
    container: nextjs_material_kit/* container */.nC,
    space50: {
        height: "50px",
        display: "block"
    },
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    typo: {
        paddingLeft: "25%",
        marginBottom: "40px",
        position: "relative",
        width: "100%"
    },
    note: {
        fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
        bottom: "10px",
        color: "#c0c1c2",
        display: "block",
        fontWeight: "400",
        fontSize: "13px",
        lineHeight: "13px",
        left: "0",
        marginLeft: "20px",
        position: "absolute",
        width: "260px"
    },
    marginLeft: {
        marginLeft: "auto !important"
    },
    ...imagesStyles/* default */.Z
};
/* harmony default export */ const componentsSections_typographyStyle = (typographyStyle_typographyStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionTypography.js


// @material-ui/core components

// @material-ui/icons
// core components











const SectionTypography_useStyles = (0,styles_.makeStyles)(componentsSections_typographyStyle);
function SectionTypography() {
    const classes = SectionTypography_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: classes.container,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "typography",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: classes.title,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Typography"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 3"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 4"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 5"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 6"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: classes.title,
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: classes.title,
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 3"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: classes.title,
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Header 4"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: classes.title,
                                            children: "The Life of Material Kit"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Paragraph"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Quote"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Quote, {
                                            text: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at.",
                                            author: " Kanye West, Musician"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Muted Text"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Muted, {
                                            children: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers..."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Primary Text"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Primary, {
                                            children: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers..."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Info Text"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Info, {
                                            children: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers..."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Success Text"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Success, {
                                            children: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers..."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Warning Text"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Warning, {
                                            children: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers..."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Danger Text"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Danger, {
                                            children: "I will be the leader of a company that ends up being worth billions of dollars, because I got the answers..."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: classes.typo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.note,
                                            children: "Small Tag"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                            children: [
                                                "Header with small subtitle",
                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Small, {
                                                    children: [
                                                        "Use ",
                                                        '"Small"',
                                                        " tag for the headers"
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.space50
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "images",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: classes.title,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Images"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Rounded Image"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/faces/avatar.jpg",
                                            alt: "...",
                                            className: classes.imgRounded + " " + classes.imgFluid
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 2,
                                    className: classes.marginLeft,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Circle Image"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/faces/avatar.jpg",
                                            alt: "...",
                                            className: classes.imgRoundedCircle + " " + classes.imgFluid
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 2,
                                    className: classes.marginLeft,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Rounded Raised"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/faces/avatar.jpg",
                                            alt: "...",
                                            className: classes.imgRaised + " " + classes.imgRounded + " " + classes.imgFluid
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 2,
                                    className: classes.marginLeft,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Circle Raised"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/faces/avatar.jpg",
                                            alt: "...",
                                            className: classes.imgRaised + " " + classes.imgRoundedCircle + " " + classes.imgFluid
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {})
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.space50
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: external "react-datetime"
const external_react_datetime_namespaceObject = require("react-datetime");
var external_react_datetime_default = /*#__PURE__*/__webpack_require__.n(external_react_datetime_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/Slide"
const Slide_namespaceObject = require("@material-ui/core/Slide");
var Slide_default = /*#__PURE__*/__webpack_require__.n(Slide_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/Dialog"
const Dialog_namespaceObject = require("@material-ui/core/Dialog");
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/DialogTitle"
const DialogTitle_namespaceObject = require("@material-ui/core/DialogTitle");
var DialogTitle_default = /*#__PURE__*/__webpack_require__.n(DialogTitle_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/DialogContent"
const DialogContent_namespaceObject = require("@material-ui/core/DialogContent");
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/core/DialogActions"
const DialogActions_namespaceObject = require("@material-ui/core/DialogActions");
var DialogActions_default = /*#__PURE__*/__webpack_require__.n(DialogActions_namespaceObject);
// EXTERNAL MODULE: external "@material-ui/core/Tooltip"
var Tooltip_ = __webpack_require__(9641);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip_);
;// CONCATENATED MODULE: external "@material-ui/core/Popover"
const Popover_namespaceObject = require("@material-ui/core/Popover");
var Popover_default = /*#__PURE__*/__webpack_require__.n(Popover_namespaceObject);
;// CONCATENATED MODULE: external "@material-ui/icons/LibraryBooks"
const LibraryBooks_namespaceObject = require("@material-ui/icons/LibraryBooks");
var LibraryBooks_default = /*#__PURE__*/__webpack_require__.n(LibraryBooks_namespaceObject);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/modalStyle.js
const modalStyle = {
    modal: {
        borderRadius: "6px"
    },
    modalHeader: {
        borderBottom: "none",
        paddingTop: "24px",
        paddingRight: "24px",
        paddingBottom: "0",
        paddingLeft: "24px",
        minHeight: "16.43px"
    },
    modalTitle: {
        margin: "0",
        lineHeight: "1.42857143"
    },
    modalCloseButton: {
        color: "#999999",
        marginTop: "-12px",
        WebkitAppearance: "none",
        padding: "0",
        cursor: "pointer",
        background: "0 0",
        border: "0",
        fontSize: "inherit",
        opacity: ".9",
        textShadow: "none",
        fontWeight: "700",
        lineHeight: "1",
        float: "right"
    },
    modalClose: {
        width: "16px",
        height: "16px"
    },
    modalBody: {
        paddingTop: "24px",
        paddingRight: "24px",
        paddingBottom: "16px",
        paddingLeft: "24px",
        position: "relative"
    },
    modalFooter: {
        padding: "15px",
        textAlign: "right",
        paddingTop: "0",
        margin: "0"
    },
    modalFooterCenter: {
        marginLeft: "auto",
        marginRight: "auto"
    }
};
/* harmony default export */ const nextjs_material_kit_modalStyle = (modalStyle);

// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit/tooltipsStyle.js
var tooltipsStyle = __webpack_require__(7745);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/popoverStyles.js
const popoverStyles = {
    popover: {
        padding: "0",
        boxShadow: "0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)",
        lineHeight: "1.5em",
        background: "#fff",
        border: "none",
        borderRadius: "3px",
        display: "block",
        maxWidth: "276px",
        fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
        fontStyle: "normal",
        fontWeight: "400",
        textAlign: "start",
        textDecoration: "none",
        textShadow: "none",
        textTransform: "none",
        letterSpacing: "normal",
        wordBreak: "normal",
        wordSpacing: "normal",
        whiteSpace: "normal",
        lineBreak: "auto",
        fontSize: "0.875rem",
        wordWrap: "break-word"
    },
    popoverBottom: {
        marginTop: "5px"
    },
    popoverHeader: {
        backgroundColor: "#fff",
        border: "none",
        padding: "15px 15px 5px",
        fontSize: "1.125rem",
        margin: "0",
        color: "#555",
        borderTopLeftRadius: "calc(0.3rem - 1px)",
        borderTopRightRadius: "calc(0.3rem - 1px)"
    },
    popoverBody: {
        padding: "10px 15px 15px",
        lineHeight: "1.4",
        color: "#555"
    }
};
/* harmony default export */ const nextjs_material_kit_popoverStyles = (popoverStyles);

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/javascriptStyles.js




const javascriptStyles = {
    section: {
        padding: "70px 0 0"
    },
    container: nextjs_material_kit/* container */.nC,
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    icon: {
        width: "17px",
        height: "17px",
        marginRight: "4px"
    },
    ...nextjs_material_kit_modalStyle,
    label: {
        color: "rgba(0, 0, 0, 0.26)",
        cursor: "pointer",
        display: "inline-flex",
        fontSize: "14px",
        transition: "0.3s ease all",
        lineHeight: "1.428571429",
        fontWeight: "400",
        paddingLeft: "0",
        letterSpacing: "normal"
    },
    ...tooltipsStyle/* default */.Z,
    ...nextjs_material_kit_popoverStyles
};
/* harmony default export */ const componentsSections_javascriptStyles = (javascriptStyles);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionJavascript.js


// react plugin for creating date-time-picker

// @material-ui/core components











// @material-ui/icons


// core components




const SectionJavascript_useStyles = (0,styles_.makeStyles)(componentsSections_javascriptStyles);
const Transition = /*#__PURE__*/ external_react_default().forwardRef(function Transition(props, ref) {
    return /*#__PURE__*/ jsx_runtime_.jsx((Slide_default()), {
        direction: "down",
        ref: ref,
        ...props
    });
});
Transition.displayName = "Transition";
function SectionJavascript() {
    const classes = SectionJavascript_useStyles();
    const [anchorElLeft, setAnchorElLeft] = external_react_default().useState(null);
    const [anchorElTop, setAnchorElTop] = external_react_default().useState(null);
    const [anchorElBottom, setAnchorElBottom] = external_react_default().useState(null);
    const [anchorElRight, setAnchorElRight] = external_react_default().useState(null);
    const [classicModal, setClassicModal] = external_react_default().useState(false);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: classes.container,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.title,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "Javascript components"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                            xs: 12,
                            sm: 12,
                            md: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: classes.title,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Modal"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                        xs: 12,
                                        sm: 12,
                                        md: 6,
                                        lg: 4,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                                                color: "primary",
                                                block: true,
                                                onClick: ()=>setClassicModal(true),
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((LibraryBooks_default()), {
                                                        className: classes.icon
                                                    }),
                                                    "Classic"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dialog_default()), {
                                                classes: {
                                                    root: classes.center,
                                                    paper: classes.modal
                                                },
                                                open: classicModal,
                                                TransitionComponent: Transition,
                                                keepMounted: true,
                                                onClose: ()=>setClassicModal(false),
                                                "aria-labelledby": "classic-modal-slide-title",
                                                "aria-describedby": "classic-modal-slide-description",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((DialogTitle_default()), {
                                                        id: "classic-modal-slide-title",
                                                        disableTypography: true,
                                                        className: classes.modalHeader,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                                className: classes.modalCloseButton,
                                                                "aria-label": "Close",
                                                                color: "inherit",
                                                                onClick: ()=>setClassicModal(false),
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                                                                    className: classes.modalClose
                                                                })
                                                            }, "close"),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                className: classes.modalTitle,
                                                                children: "Modal title"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((DialogContent_default()), {
                                                        id: "classic-modal-slide-description",
                                                        className: classes.modalBody,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            children: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar."
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((DialogActions_default()), {
                                                        className: classes.modalFooter,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                color: "transparent",
                                                                simple: true,
                                                                children: "Nice Button"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                                onClick: ()=>setClassicModal(false),
                                                                color: "danger",
                                                                simple: true,
                                                                children: "Close"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 12,
                                    md: 12,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.title,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                children: "Datetime Picker"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                                                xs: 12,
                                                sm: 12,
                                                md: 6,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                                                        className: classes.label,
                                                        children: "Datetime Picker"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((FormControl_default()), {
                                                        fullWidth: true,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_datetime_default()), {
                                                            inputProps: {
                                                                placeholder: "Datetime Picker Here"
                                                            }
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                            xs: 12,
                            sm: 12,
                            md: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: classes.title,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Popovers"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    onClick: (event)=>setAnchorElLeft(event.currentTarget),
                                    children: "On left"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
                                    classes: {
                                        paper: classes.popover
                                    },
                                    open: Boolean(anchorElLeft),
                                    anchorEl: anchorElLeft,
                                    onClose: ()=>setAnchorElLeft(null),
                                    anchorOrigin: {
                                        vertical: "center",
                                        horizontal: "left"
                                    },
                                    transformOrigin: {
                                        vertical: "center",
                                        horizontal: "right"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: classes.popoverHeader,
                                            children: "Popover on left"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.popoverBody,
                                            children: "Here will be some very useful information about his popover. Here will be some very useful information about his popover."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    onClick: (event)=>setAnchorElTop(event.currentTarget),
                                    children: "On top"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
                                    classes: {
                                        paper: classes.popover
                                    },
                                    open: Boolean(anchorElTop),
                                    anchorEl: anchorElTop,
                                    onClose: ()=>setAnchorElTop(null),
                                    anchorOrigin: {
                                        vertical: "top",
                                        horizontal: "center"
                                    },
                                    transformOrigin: {
                                        vertical: "bottom",
                                        horizontal: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: classes.popoverHeader,
                                            children: "Popover on top"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.popoverBody,
                                            children: "Here will be some very useful information about his popover."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    onClick: (event)=>setAnchorElBottom(event.currentTarget),
                                    children: "On bottom"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
                                    classes: {
                                        paper: classes.popover
                                    },
                                    open: Boolean(anchorElBottom),
                                    anchorEl: anchorElBottom,
                                    onClose: ()=>setAnchorElBottom(null),
                                    anchorOrigin: {
                                        vertical: "bottom",
                                        horizontal: "center"
                                    },
                                    transformOrigin: {
                                        vertical: "top",
                                        horizontal: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: classes.popoverHeader,
                                            children: "Popover on bottom"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.popoverBody,
                                            children: "Here will be some very useful information about his popover."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    onClick: (event)=>setAnchorElRight(event.currentTarget),
                                    children: "On right"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
                                    classes: {
                                        paper: classes.popover
                                    },
                                    open: Boolean(anchorElRight),
                                    anchorEl: anchorElRight,
                                    onClose: ()=>setAnchorElRight(null),
                                    anchorOrigin: {
                                        vertical: "center",
                                        horizontal: "right"
                                    },
                                    transformOrigin: {
                                        vertical: "center",
                                        horizontal: "left"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: classes.popoverHeader,
                                            children: "Popover on right"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: classes.popoverBody,
                                            children: "Here will be some very useful information about his popover."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: classes.title,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Tooltips"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    id: "tooltip-left",
                                    title: "Tooltip on left",
                                    placement: "left",
                                    classes: {
                                        tooltip: classes.tooltip
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        children: "On left"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    id: "tooltip-top",
                                    title: "Tooltip on top",
                                    placement: "top",
                                    classes: {
                                        tooltip: classes.tooltip
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        children: "On top"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    id: "tooltip-bottom",
                                    title: "Tooltip on bottom",
                                    placement: "bottom",
                                    classes: {
                                        tooltip: classes.tooltip
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        children: "On bottom"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    id: "tooltip-right",
                                    title: "Tooltip on right",
                                    placement: "right",
                                    classes: {
                                        tooltip: classes.tooltip
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        children: "On right"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.title,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Carousel"
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./pages-sections/Components-Sections/SectionCarousel.js
var SectionCarousel = __webpack_require__(6382);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/completedStyle.js

const completedStyle = {
    section: {
        padding: "70px 0"
    },
    container: {
        ...nextjs_material_kit/* container */.nC,
        textAlign: "center !important"
    }
};
/* harmony default export */ const componentsSections_completedStyle = (completedStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionCompletedExamples.js


// @material-ui/core components

// @material-ui/icons
// core components



const SectionCompletedExamples_useStyles = (0,styles_.makeStyles)(componentsSections_completedStyle);
function SectionCompletedExamples() {
    const classes = SectionCompletedExamples_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: classes.container,
            children: /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                justify: "center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                    xs: 12,
                    sm: 12,
                    md: 8,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Completed with examples"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            children: [
                                "The kit comes with three pre-built pages to help you get started faster. You can change the text and images and you",
                                "'",
                                "re good to go. More importantly, looking at them will give you a picture of what you can build with this powerful kit."
                            ]
                        })
                    ]
                })
            })
        })
    });
};

// EXTERNAL MODULE: ./components/Card/CardFooter.js + 1 modules
var CardFooter = __webpack_require__(8696);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/loginStyle.js

const loginStyle = {
    section: {
        minHeight: "110vh",
        maxHeight: "1600px",
        overflow: "hidden",
        padding: "70px 0",
        backgroundPosition: "top center",
        backgroundSize: "cover",
        margin: "0",
        border: "0",
        display: "flex",
        alignItems: "center",
        backgroundImage: "url('/img/sign.jpg')"
    },
    container: nextjs_material_kit/* container */.nC,
    form: {
        margin: "0"
    },
    cardHeader: {
        width: "auto",
        textAlign: "center",
        marginLeft: "20px",
        marginRight: "20px",
        marginTop: "-40px",
        padding: "20px 0",
        marginBottom: "15px"
    },
    socialIcons: {
        maxWidth: "24px",
        marginTop: "0",
        width: "100%",
        transform: "none",
        left: "0",
        top: "0",
        height: "100%",
        lineHeight: "41px",
        fontSize: "20px"
    },
    divider: {
        marginTop: "30px",
        marginBottom: "0px",
        textAlign: "center"
    },
    cardFooter: {
        paddingTop: "0rem",
        border: "0",
        borderRadius: "6px",
        justifyContent: "center !important"
    },
    socialLine: {
        marginTop: "1rem",
        textAlign: "center",
        padding: "0"
    },
    inputIconsColor: {
        color: "#495057"
    }
};
/* harmony default export */ const componentsSections_loginStyle = (loginStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionLogin.js


// @material-ui/core components



// @material-ui/icons


// core components









const SectionLogin_useStyles = (0,styles_.makeStyles)(componentsSections_loginStyle);
function SectionLogin() {
    const classes = SectionLogin_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: classes.container,
            children: /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                justify: "center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                    xs: 12,
                    sm: 6,
                    md: 4,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Card/* default */.Z, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                            className: classes.form,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardHeader, {
                                    color: "primary",
                                    className: classes.cardHeader,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Login"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: classes.socialLine,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    justIcon: true,
                                                    href: "#pablo",
                                                    target: "_blank",
                                                    color: "transparent",
                                                    onClick: (e)=>e.preventDefault(),
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: classes.socialIcons + " fab fa-twitter"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    justIcon: true,
                                                    href: "#pablo",
                                                    target: "_blank",
                                                    color: "transparent",
                                                    onClick: (e)=>e.preventDefault(),
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: classes.socialIcons + " fab fa-facebook"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                    justIcon: true,
                                                    href: "#pablo",
                                                    target: "_blank",
                                                    color: "transparent",
                                                    onClick: (e)=>e.preventDefault(),
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: classes.socialIcons + " fab fa-google-plus-g"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: classes.divider,
                                    children: "Or Be Classical"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardBody/* default */.Z, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                            labelText: "First Name...",
                                            id: "first",
                                            formControlProps: {
                                                fullWidth: true
                                            },
                                            inputProps: {
                                                type: "text",
                                                endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                                    position: "end",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((People_default()), {
                                                        className: classes.inputIconsColor
                                                    })
                                                })
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                            labelText: "Email...",
                                            id: "email",
                                            formControlProps: {
                                                fullWidth: true
                                            },
                                            inputProps: {
                                                type: "email",
                                                endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                                    position: "end",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Email_default()), {
                                                        className: classes.inputIconsColor
                                                    })
                                                })
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(CustomInput, {
                                            labelText: "Password",
                                            id: "pass",
                                            formControlProps: {
                                                fullWidth: true
                                            },
                                            inputProps: {
                                                type: "password",
                                                endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                                    position: "end",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Icon_default()), {
                                                        className: classes.inputIconsColor,
                                                        children: "lock_outline"
                                                    })
                                                }),
                                                autoComplete: "off"
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(CardFooter/* default */.Z, {
                                    className: classes.cardFooter,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        simple: true,
                                        color: "primary",
                                        size: "lg",
                                        children: "Get started"
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/exampleStyle.js


const exampleStyle = {
    section: {
        padding: "70px 0"
    },
    container: {
        ...nextjs_material_kit/* containerFluid */.ah,
        textAlign: "center !important"
    },
    ...imagesStyles/* default */.Z,
    link: {
        textDecoration: "none"
    }
};
/* harmony default export */ const componentsSections_exampleStyle = (exampleStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionExamples.js


// react components for routing our app without refresh

// @material-ui/core components

// @material-ui/icons
// core components




const SectionExamples_useStyles = (0,styles_.makeStyles)(componentsSections_exampleStyle);
function SectionExamples() {
    const classes = SectionExamples_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: classes.container,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                justify: "center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                        xs: 12,
                        sm: 12,
                        md: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/landing",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: classes.link,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/img/landing.jpg",
                                        alt: "...",
                                        className: classes.imgRaised + " " + classes.imgRounded + " " + classes.imgFluid
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        size: "lg",
                                        simple: true,
                                        children: "View landing page"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                        xs: 12,
                        sm: 12,
                        md: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/profile",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: classes.link,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/img/profile.jpg",
                                        alt: "...",
                                        className: classes.imgRaised + " " + classes.imgRounded + " " + classes.imgFluid
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        color: "primary",
                                        size: "lg",
                                        simple: true,
                                        children: "View profile page"
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/downloadStyle.js

const downloadStyle = {
    section: {
        padding: "70px 0"
    },
    container: nextjs_material_kit/* container */.nC,
    textCenter: {
        textAlign: "center"
    },
    sharingArea: {
        marginTop: "80px"
    },
    socials: {
        maxWidth: "24px",
        marginTop: "0",
        width: "100%",
        transform: "none",
        left: "0",
        top: "0",
        height: "100%",
        fontSize: "20px",
        marginRight: "4px"
    }
};
/* harmony default export */ const componentsSections_downloadStyle = (downloadStyle);

;// CONCATENATED MODULE: ./pages-sections/Components-Sections/SectionDownload.js
/*eslint-disable*/ 

// @material-ui/core components

// @material-ui/icons



// core components

const SectionDownload_useStyles = (0,styles_.makeStyles)(componentsSections_downloadStyle);
function SectionDownload() {
    const classes = SectionDownload_useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: classes.container,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                    className: classes.textCenter,
                    justify: "center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                            xs: 12,
                            sm: 12,
                            md: 8,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    children: "Do you love this UI Kit?"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Cause if you do, it can be yours for FREE. Hit the buttons below to navigate to our website where you can find the kit. We also have the Bootstrap 4 version on plain HTML. Start a new project or give an old Bootstrap project a new look!"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                            xs: 12,
                            sm: 8,
                            md: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    color: "primary",
                                    size: "lg",
                                    href: "https://www.creative-tim.com/product/nextjs-material-kit?ref=njsmk-download-section",
                                    target: "_blank",
                                    children: "Free NextJS Download"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    color: "primary",
                                    size: "lg",
                                    href: "https://www.creative-tim.com/product/material-kit-react?ref=njsmk-download-section",
                                    target: "_blank",
                                    children: "Free React Downoad"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridContainer/* default */.Z, {
                    className: classes.textCenter,
                    justify: "center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                            xs: 12,
                            sm: 12,
                            md: 8,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    children: "Want more?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                    children: [
                                        "We've just launched",
                                        " ",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: "#pablo",
                                            onClick: (e)=>e.preventDefault(),
                                            children: [
                                                "NextJS Material Kit PRO",
                                                " "
                                            ]
                                        }),
                                        ".It has a huge number of components, sections and example pages. Start Your Development With A Badass Material-UI and NexJS Kit inspired by Material Design."
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(GridItem/* default */.Z, {
                            xs: 12,
                            sm: 8,
                            md: 10,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    color: "rose",
                                    size: "lg",
                                    href: "https://www.creative-tim.com/product/nextjs-material-kit-pro?ref=njsmk-download-section",
                                    target: "_blank",
                                    children: "NextJS Material Kit PRO"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    color: "rose",
                                    size: "lg",
                                    href: "https://www.creative-tim.com/product/material-kit-pro-react?ref=njsmk-download-section",
                                    target: "_blank",
                                    children: "Material Kit PRO React"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: classes.textCenter + " " + classes.sharingArea,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "Thank you for supporting us!"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                            color: "twitter",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: classes.socials + " fab fa-twitter"
                                }),
                                " Tweet"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                            color: "facebook",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: classes.socials + " fab fa-facebook-square"
                                }),
                                " Share"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                            color: "google",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: classes.socials + " fab fa-google-plus-g"
                                }),
                                "Share"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Button/* default */.Z, {
                            color: "github",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: classes.socials + " fab fa-github"
                                }),
                                " Star"
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/components.js

const componentsStyle = {
    container: nextjs_material_kit/* container */.nC,
    brand: {
        color: "#FFFFFF",
        textAlign: "left"
    },
    title: {
        fontSize: "4.2rem",
        fontWeight: "600",
        display: "inline-block",
        position: "relative"
    },
    subtitle: {
        fontSize: "1.313rem",
        maxWidth: "510px",
        margin: "10px 0 0"
    },
    main: {
        background: "#FFFFFF",
        position: "relative",
        zIndex: "3"
    },
    mainRaised: {
        margin: "-60px 30px 0px",
        borderRadius: "6px",
        boxShadow: "0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)",
        "@media (max-width: 830px)": {
            marginLeft: "10px",
            marginRight: "10px"
        }
    },
    link: {
        textDecoration: "none"
    },
    textCenter: {
        textAlign: "center"
    }
};
/* harmony default export */ const components = (componentsStyle);

;// CONCATENATED MODULE: ./pages/components.js


// nodejs library that concatenates classes

// react components for routing our app without refresh

// @material-ui/core components

// @material-ui/icons
// core components







// sections for this page













const components_useStyles = (0,styles_.makeStyles)(components);
function Components(props) {
    const classes = components_useStyles();
    const { ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                brand: "NextJS Material Kit",
                rightLinks: /*#__PURE__*/ jsx_runtime_.jsx(HeaderLinks/* default */.Z, {}),
                fixed: true,
                color: "transparent",
                changeColorOnScroll: {
                    height: 400,
                    color: "white"
                },
                ...rest
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Parallax/* default */.Z, {
                image: "/img/nextjs_header.jpg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: classes.container,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(GridContainer/* default */.Z, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: classes.brand,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: classes.title,
                                        children: "NextJS Material Kit."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: classes.subtitle,
                                        children: "A Badass Material Kit based on Material-UI and NextJS."
                                    })
                                ]
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: external_classnames_default()(classes.main, classes.mainRaised),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionBasics, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionNavbars, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionTabs, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionPills, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionNotifications, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionTypography, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionJavascript, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionCarousel/* default */.Z, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionCompletedExamples, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionLogin, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(GridItem/* default */.Z, {
                        md: 12,
                        className: classes.textCenter,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/login",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: classes.link,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    color: "primary",
                                    size: "lg",
                                    simple: true,
                                    children: "View Login Page"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionExamples, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionDownload, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
};


/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8736:
/***/ ((module) => {

module.exports = require("@material-ui/core/AppBar");

/***/ }),

/***/ 2610:
/***/ ((module) => {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ 7730:
/***/ ((module) => {

module.exports = require("@material-ui/core/ClickAwayListener");

/***/ }),

/***/ 2217:
/***/ ((module) => {

module.exports = require("@material-ui/core/Divider");

/***/ }),

/***/ 5555:
/***/ ((module) => {

module.exports = require("@material-ui/core/Drawer");

/***/ }),

/***/ 5811:
/***/ ((module) => {

module.exports = require("@material-ui/core/FormControl");

/***/ }),

/***/ 3266:
/***/ ((module) => {

module.exports = require("@material-ui/core/Grid");

/***/ }),

/***/ 6491:
/***/ ((module) => {

module.exports = require("@material-ui/core/Grow");

/***/ }),

/***/ 6403:
/***/ ((module) => {

module.exports = require("@material-ui/core/Hidden");

/***/ }),

/***/ 7886:
/***/ ((module) => {

module.exports = require("@material-ui/core/Icon");

/***/ }),

/***/ 3974:
/***/ ((module) => {

module.exports = require("@material-ui/core/IconButton");

/***/ }),

/***/ 3302:
/***/ ((module) => {

module.exports = require("@material-ui/core/Input");

/***/ }),

/***/ 8190:
/***/ ((module) => {

module.exports = require("@material-ui/core/InputLabel");

/***/ }),

/***/ 5031:
/***/ ((module) => {

module.exports = require("@material-ui/core/List");

/***/ }),

/***/ 6256:
/***/ ((module) => {

module.exports = require("@material-ui/core/ListItem");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("@material-ui/core/MenuItem");

/***/ }),

/***/ 73:
/***/ ((module) => {

module.exports = require("@material-ui/core/MenuList");

/***/ }),

/***/ 640:
/***/ ((module) => {

module.exports = require("@material-ui/core/Paper");

/***/ }),

/***/ 2767:
/***/ ((module) => {

module.exports = require("@material-ui/core/Popper");

/***/ }),

/***/ 5722:
/***/ ((module) => {

module.exports = require("@material-ui/core/Toolbar");

/***/ }),

/***/ 9641:
/***/ ((module) => {

module.exports = require("@material-ui/core/Tooltip");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 3386:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles/makeStyles");

/***/ }),

/***/ 2105:
/***/ ((module) => {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ 1677:
/***/ ((module) => {

module.exports = require("@material-ui/icons/Chat");

/***/ }),

/***/ 5652:
/***/ ((module) => {

module.exports = require("@material-ui/icons/Delete");

/***/ }),

/***/ 9899:
/***/ ((module) => {

module.exports = require("@material-ui/icons/Favorite");

/***/ }),

/***/ 9616:
/***/ ((module) => {

module.exports = require("@material-ui/icons/LocationOn");

/***/ }),

/***/ 4176:
/***/ ((module) => {

module.exports = require("@material-ui/icons/Menu");

/***/ }),

/***/ 9723:
/***/ ((module) => {

module.exports = require("@material-ui/icons/WhatsApp");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3094:
/***/ ((module) => {

module.exports = require("react-scroll");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,957], () => (__webpack_exec__(5547)));
module.exports = __webpack_exports__;

})();