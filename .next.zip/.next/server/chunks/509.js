"use strict";
exports.id = 509;
exports.ids = [509];
exports.modules = {

/***/ 509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ LandingPage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(8308);
// EXTERNAL MODULE: ./components/Header/Header.js + 1 modules
var Header = __webpack_require__(9152);
// EXTERNAL MODULE: ./components/Footer/Footer.js + 1 modules
var Footer = __webpack_require__(6356);
// EXTERNAL MODULE: ./components/Grid/GridContainer.js
var Grid_GridContainer = __webpack_require__(4041);
// EXTERNAL MODULE: ./components/Grid/GridItem.js
var Grid_GridItem = __webpack_require__(6680);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "@material-ui/core/Grid"
var Grid_ = __webpack_require__(3266);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
;// CONCATENATED MODULE: ./components/Grid/GridItemT.js


// nodejs library to set properties for components

// @material-ui/core components


const styles = {
    grid: {
        width: "100%",
        height: "100%",
        paddingRight: "10px",
        paddingLeft: "5px",
        paddingTop: "0px",
        flexBasis: "auto"
    }
};
const useStyles = (0,styles_.makeStyles)(styles);
function GridItemT_GridItem(props) {
    const classes = useStyles();
    const { children , className , ...rest } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
        item: true,
        ...rest,
        className: classes.grid + " " + className,
        children: children
    });
};
GridItemT_GridItem.defaultProps = {
    className: ""
};
GridItemT_GridItem.propTypes = {
    children: (external_prop_types_default()).node,
    className: (external_prop_types_default()).string
};

// EXTERNAL MODULE: ./components/CustomButtons/Button.js + 1 modules
var CustomButtons_Button = __webpack_require__(4286);
// EXTERNAL MODULE: ./components/Header/HeaderLinks.js
var HeaderLinks = __webpack_require__(5017);
// EXTERNAL MODULE: ./components/Parallax/Parallax.js + 1 modules
var Parallax = __webpack_require__(8602);
// EXTERNAL MODULE: external "@material-ui/core/Icon"
var Icon_ = __webpack_require__(7886);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit.js
var nextjs_material_kit = __webpack_require__(6547);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/landingPage.js

const landingPageStyle = {
    container: {
        zIndex: "1",
        color: "#FFFFFF",
        ...nextjs_material_kit/* container */.nC
    },
    containerTwo: {
        width: "100%"
    },
    title: {
        display: "inline-block",
        lineHeight: "1",
        marginTop: "-15px",
        marginLeft: "7px",
        textAlign: "left",
        fontSize: "2.340rem",
        color: "#000",
        fontWeight: "700",
        fontFamily: `"Roboto Slab", "Times New Roman", serif`,
        textDecoration: "none"
    },
    subtitle: {
        fontSize: "1.313rem",
        maxWidth: "500px",
        margin: "10px auto 0"
    },
    customParallax: {
    },
    titleOne: {
        ...nextjs_material_kit/* title */.TN,
        marginBottom: "1rem",
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    fullWidthGridContainer: {
        width: "100%"
    },
    responsiveSubtitle: {
        fontSize: "1.110rem",
        fontWeight: "50",
        textAlign: "left",
        marginTop: "-2px",
        lineHeight: "1"
    },
    main: {
        background: "#FFFFFF",
        position: "relative",
        zIndex: "3"
    },
    mainRaised: {
        margin: "-60px 30px 0px",
        borderRadius: "6px",
        boxShadow: "0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)"
    }
};
/* harmony default export */ const landingPage = (landingPageStyle);

// EXTERNAL MODULE: external "@material-ui/icons/Chat"
var Chat_ = __webpack_require__(1677);
var Chat_default = /*#__PURE__*/__webpack_require__.n(Chat_);
// EXTERNAL MODULE: external "@material-ui/icons/VerifiedUser"
var VerifiedUser_ = __webpack_require__(8139);
var VerifiedUser_default = /*#__PURE__*/__webpack_require__.n(VerifiedUser_);
// EXTERNAL MODULE: external "@material-ui/icons/Fingerprint"
var Fingerprint_ = __webpack_require__(952);
var Fingerprint_default = /*#__PURE__*/__webpack_require__.n(Fingerprint_);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/components/infoStyle.js

const infoStyle = {
    infoArea: {
        maxWidth: "360px",
        margin: "0 auto",
        padding: "0px"
    },
    iconWrapper: {
        float: "left",
        marginTop: "24px",
        marginRight: "10px"
    },
    primary: {
        color: nextjs_material_kit/* primaryColor */.lr
    },
    warning: {
        color: nextjs_material_kit/* warningColor */.MA
    },
    danger: {
        color: nextjs_material_kit/* dangerColor */.E7
    },
    success: {
        color: nextjs_material_kit/* successColor */.nq
    },
    info: {
        color: nextjs_material_kit/* infoColor */.bE
    },
    rose: {
        color: nextjs_material_kit/* roseColor */.An
    },
    gray: {
        color: nextjs_material_kit/* grayColor */.X_
    },
    icon: {
        width: "36px",
        height: "36px"
    },
    descriptionWrapper: {
        color: nextjs_material_kit/* grayColor */.X_,
        overflow: "hidden"
    },
    title: nextjs_material_kit/* title */.TN,
    description: {
        color: nextjs_material_kit/* grayColor */.X_,
        overflow: "hidden",
        marginTop: "0px",
        fontSize: "14px"
    },
    iconWrapperVertical: {
        float: "none"
    },
    iconVertical: {
        width: "61px",
        height: "61px"
    }
};
/* harmony default export */ const components_infoStyle = (infoStyle);

;// CONCATENATED MODULE: ./components/InfoArea/InfoArea.js


// nodejs library to set properties for components

// nodejs library that concatenates classes

// @material-ui/core components


const InfoArea_useStyles = (0,styles_.makeStyles)(components_infoStyle);
function InfoArea(props) {
    const classes = InfoArea_useStyles();
    const { title , description , iconColor , vertical  } = props;
    const iconWrapper = external_classnames_default()({
        [classes.iconWrapper]: true,
        [classes[iconColor]]: true,
        [classes.iconWrapperVertical]: vertical
    });
    const iconClasses = external_classnames_default()({
        [classes.iconVertical]: vertical
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.infoArea,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: classes.descriptionWrapper,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    className: classes.title,
                    children: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: classes.description,
                    children: description
                })
            ]
        })
    });
};
InfoArea.defaultProps = {
    iconColor: "gray"
};
InfoArea.propTypes = {
    icon: (external_prop_types_default()).object.isRequired,
    title: external_prop_types_default().oneOfType([
        (external_prop_types_default()).string,
        (external_prop_types_default()).node
    ]).isRequired,
    description: (external_prop_types_default()).string.isRequired,
    iconColor: external_prop_types_default().oneOf([
        "primary",
        "warning",
        "danger",
        "success",
        "info",
        "rose",
        "gray"
    ]),
    vertical: (external_prop_types_default()).bool
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/landingPageSections/productStyle.js

const productStyle = {
    section: {
        padding: "70px 0",
        textAlign: "center"
    },
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginBottom: "1rem",
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    titleOne: {
        ...nextjs_material_kit/* title */.TN,
        marginBottom: "1rem",
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    description: {
        color: "#999"
    }
};
/* harmony default export */ const landingPageSections_productStyle = (productStyle);

;// CONCATENATED MODULE: ./pages-sections/LandingPage-Sections/ProductSection.js


// @material-ui/core components

// @material-ui/icons



// import WhatsAppIcon from '@mui/icons-material/WhatsApp';
// core components




const ProductSection_useStyles = (0,styles_.makeStyles)(landingPageSections_productStyle);
function ProductSection() {
    const classes = ProductSection_useStyles();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: classes.section,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridContainer/* default */.Z, {
                justify: "center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                    xs: 12,
                    sm: 12,
                    md: 8,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: classes.titleOne,
                            children: "Conhe\xe7a o Residencial Curu\xe7\xe1"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            className: classes.description,
                            children: "Venha morar na Vila Guarani em Mau\xe1! Os apartamentos do Residencial Curu\xe7\xe1 s\xe3o perfeitos para voc\xea e sua fam\xedlia, com su\xedte e varanda grill. N\xe3o perca essa oportunidade!"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridContainer/* default */.Z, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "img/faces/map.png",
                                    alt: "caixa",
                                    width: 50,
                                    height: 50,
                                    className: classes.imgRoundedCircle + " " + classes.imgFluid
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(InfoArea, {
                                    title: "\xd3tima Localiza\xe7\xe3o",
                                    description: "Desfrute de uma \xf3tima localiza\xe7\xe3o e venha conhecer esse empreendimento que une conforto, modernidade e conveni\xeancia.",
                                    icon: (Chat_default()),
                                    iconColor: "info",
                                    vertical: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "img/faces/apartmentDF.png",
                                    alt: "caixa",
                                    width: 50,
                                    height: 50,
                                    className: classes.imgRoundedCircle + " " + classes.imgFluid
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(InfoArea, {
                                    title: "Sacada Grill",
                                    description: "Apartamentos com varanda grill, op\xe7\xf5es com 2 ou 3 dormit\xf3rios, planta com op\xe7\xe3o de 53 m\xb2, 66m\xb2, 76 m\xb2 3 79 m\xb2, escolha a melhor op\xe7ao que atende sua fam\xedlia.",
                                    icon: (VerifiedUser_default()),
                                    iconColor: "success",
                                    vertical: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "img/faces/caixa.png",
                                    alt: "caixa",
                                    width: 50,
                                    height: 50,
                                    className: classes.imgRoundedCircle + " " + classes.imgFluid
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(InfoArea, {
                                    title: "Facilidades com a Caixa Econ\xf4mica",
                                    description: "Entrada facilitada, juros mais baixos do mercado imobili\xe1rio, tornando seu sonho de comprar seu apartamento mais acess\xedvel. N\xe3o deixe de conferir os valores e garantir o seu lugar no Residencial Curu\xe7a. Saiba mais detalhes e entre em contato conosco para mais informa\xe7\xf5es.",
                                    icon: (Fingerprint_default()),
                                    vertical: true
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/Card/Card.js + 1 modules
var Card_Card = __webpack_require__(2406);
// EXTERNAL MODULE: ./components/Card/CardBody.js + 1 modules
var Card_CardBody = __webpack_require__(7585);
// EXTERNAL MODULE: ./components/Card/CardFooter.js + 1 modules
var Card_CardFooter = __webpack_require__(8696);
// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit/imagesStyles.js
var imagesStyles = __webpack_require__(266);
;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/landingPageSections/teamStyle.js


const teamStyle = {
    section: {
        padding: "70px 0",
        textAlign: "center"
    },
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginBottom: "1rem",
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none"
    },
    ...imagesStyles/* default */.Z,
    itemGrid: {
        marginLeft: "auto",
        marginRight: "auto"
    },
    cardTitle: nextjs_material_kit/* cardTitle */.X5,
    smallTitle: {
        color: "#6c757d"
    },
    description: {
        color: "#999"
    },
    justifyCenter: {
        justifyContent: "center !important"
    },
    socials: {
        marginTop: "0",
        width: "100%",
        transform: "none",
        left: "0",
        top: "0",
        height: "100%",
        lineHeight: "41px",
        fontSize: "20px",
        color: "#999"
    },
    margin5: {
        margin: "5px"
    }
};
/* harmony default export */ const landingPageSections_teamStyle = (teamStyle);

;// CONCATENATED MODULE: ./pages-sections/LandingPage-Sections/TeamSection.js


// nodejs library that concatenates classes

// @material-ui/core components

// @material-ui/icons
// core components







const TeamSection_useStyles = (0,styles_.makeStyles)(landingPageSections_teamStyle);
function TeamSection() {
    const classes = TeamSection_useStyles();
    const imageClasses = classNames(classes.imgRaised, classes.imgRoundedCircle, classes.imgFluid);
    return /*#__PURE__*/ _jsxs("div", {
        className: classes.section,
        children: [
            /*#__PURE__*/ _jsx("h2", {
                className: classes.title,
                children: "Here is our team"
            }),
            /*#__PURE__*/ _jsx("div", {
                children: /*#__PURE__*/ _jsxs(GridContainer, {
                    children: [
                        /*#__PURE__*/ _jsx(GridItem, {
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: /*#__PURE__*/ _jsxs(Card, {
                                plain: true,
                                children: [
                                    /*#__PURE__*/ _jsx(GridItem, {
                                        xs: 12,
                                        sm: 12,
                                        md: 6,
                                        className: classes.itemGrid,
                                        children: /*#__PURE__*/ _jsx("img", {
                                            src: "/img/faces/avatar.jpg",
                                            alt: "...",
                                            className: imageClasses
                                        })
                                    }),
                                    /*#__PURE__*/ _jsxs("h4", {
                                        className: classes.cardTitle,
                                        children: [
                                            "Gigi Hadid",
                                            /*#__PURE__*/ _jsx("br", {}),
                                            /*#__PURE__*/ _jsx("small", {
                                                className: classes.smallTitle,
                                                children: "Model"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ _jsx(CardBody, {
                                        children: /*#__PURE__*/ _jsxs("p", {
                                            className: classes.description,
                                            children: [
                                                "You can write here details about one of your team members. You can give more details about what they do. Feel free to add some ",
                                                /*#__PURE__*/ _jsx("a", {
                                                    href: "#pablo",
                                                    children: "links"
                                                }),
                                                " for people to be able to follow them outside the site."
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ _jsxs(CardFooter, {
                                        className: classes.justifyCenter,
                                        children: [
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-twitter"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-instagram"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-facebook"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ _jsx(GridItem, {
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: /*#__PURE__*/ _jsxs(Card, {
                                plain: true,
                                children: [
                                    /*#__PURE__*/ _jsx(GridItem, {
                                        xs: 12,
                                        sm: 12,
                                        md: 6,
                                        className: classes.itemGrid,
                                        children: /*#__PURE__*/ _jsx("img", {
                                            src: "/img/faces/christian.jpg",
                                            alt: "...",
                                            className: imageClasses
                                        })
                                    }),
                                    /*#__PURE__*/ _jsxs("h4", {
                                        className: classes.cardTitle,
                                        children: [
                                            "Christian Louboutin",
                                            /*#__PURE__*/ _jsx("br", {}),
                                            /*#__PURE__*/ _jsx("small", {
                                                className: classes.smallTitle,
                                                children: "Designer"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ _jsx(CardBody, {
                                        children: /*#__PURE__*/ _jsxs("p", {
                                            className: classes.description,
                                            children: [
                                                "You can write here details about one of your team members. You can give more details about what they do. Feel free to add some ",
                                                /*#__PURE__*/ _jsx("a", {
                                                    href: "#pablo",
                                                    children: "links"
                                                }),
                                                " for people to be able to follow them outside the site."
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ _jsxs(CardFooter, {
                                        className: classes.justifyCenter,
                                        children: [
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-twitter"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-linkedin"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ _jsx(GridItem, {
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: /*#__PURE__*/ _jsxs(Card, {
                                plain: true,
                                children: [
                                    /*#__PURE__*/ _jsx(GridItem, {
                                        xs: 12,
                                        sm: 12,
                                        md: 6,
                                        className: classes.itemGrid,
                                        children: /*#__PURE__*/ _jsx("img", {
                                            src: "/img/faces/kendall.jpg",
                                            alt: "...",
                                            className: imageClasses
                                        })
                                    }),
                                    /*#__PURE__*/ _jsxs("h4", {
                                        className: classes.cardTitle,
                                        children: [
                                            "Kendall Jenner",
                                            /*#__PURE__*/ _jsx("br", {}),
                                            /*#__PURE__*/ _jsx("small", {
                                                className: classes.smallTitle,
                                                children: "Model"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ _jsx(CardBody, {
                                        children: /*#__PURE__*/ _jsxs("p", {
                                            className: classes.description,
                                            children: [
                                                "You can write here details about one of your team members. You can give more details about what they do. Feel free to add some ",
                                                /*#__PURE__*/ _jsx("a", {
                                                    href: "#pablo",
                                                    children: "links"
                                                }),
                                                " for people to be able to follow them outside the site."
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ _jsxs(CardFooter, {
                                        className: classes.justifyCenter,
                                        children: [
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-twitter"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-instagram"
                                                })
                                            }),
                                            /*#__PURE__*/ _jsx(Button, {
                                                justIcon: true,
                                                color: "transparent",
                                                className: classes.margin5,
                                                children: /*#__PURE__*/ _jsx("i", {
                                                    className: classes.socials + " fab fa-facebook"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./styles/jss/nextjs-material-kit/pages/landingPageSections/workStyle.js

const workStyle = {
    section: {
        padding: "70px 0"
    },
    title: {
        ...nextjs_material_kit/* title */.TN,
        marginBottom: "50px",
        marginTop: "30px",
        minHeight: "32px",
        textDecoration: "none",
        textAlign: "center"
    },
    description: {
        color: "#999",
        textAlign: "center"
    },
    textCenter: {
        textAlign: "center"
    },
    textArea: {
        marginRight: "15px",
        marginLeft: "15px"
    }
};
/* harmony default export */ const landingPageSections_workStyle = (workStyle);

// EXTERNAL MODULE: external "@material-ui/core/FormControl"
var FormControl_ = __webpack_require__(5811);
var FormControl_default = /*#__PURE__*/__webpack_require__.n(FormControl_);
// EXTERNAL MODULE: external "@material-ui/core/InputLabel"
var InputLabel_ = __webpack_require__(8190);
var InputLabel_default = /*#__PURE__*/__webpack_require__.n(InputLabel_);
// EXTERNAL MODULE: external "@material-ui/core/Input"
var Input_ = __webpack_require__(3302);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input_);
// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit/components/customInputStyle.js
var customInputStyle = __webpack_require__(3341);
;// CONCATENATED MODULE: ./components/CustomInput/CustomInputEmail.js


// nodejs library to set properties for components

// nodejs library that concatenates classes

// @material-ui/core components





const CustomInputEmail_useStyles = (0,styles_.makeStyles)(customInputStyle/* default */.Z);
function CustomInputEmail(props) {
    const classes = CustomInputEmail_useStyles();
    const { formControlProps , labelText , id , labelProps , inputProps , error , white , inputRootCustomClasses , success , onChange , required  } = props;
    const labelClasses = external_classnames_default()({
        [" " + classes.labelRootError]: error,
        [" " + classes.labelRootSuccess]: success && !error
    });
    const underlineClasses = external_classnames_default()({
        [classes.underlineError]: error,
        [classes.underlineSuccess]: success && !error,
        [classes.underline]: true,
        [classes.whiteUnderline]: white
    });
    const marginTop = external_classnames_default()({
        [inputRootCustomClasses]: inputRootCustomClasses !== undefined
    });
    const inputClasses = external_classnames_default()({
        [classes.input]: true,
        [classes.whiteInput]: white
    });
    var formControlClasses;
    if (formControlProps !== undefined) {
        formControlClasses = external_classnames_default()(formControlProps.className, classes.formControl);
    } else {
        formControlClasses = classes.formControl;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((FormControl_default()), {
        ...formControlProps,
        className: formControlClasses,
        children: [
            labelText !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                className: classes.labelRoot + " " + labelClasses,
                ...labelProps,
                children: labelText
            }) : null,
            /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                classes: {
                    input: inputClasses,
                    root: marginTop,
                    disabled: classes.disabled,
                    underline: underlineClasses
                },
                onChange: onChange,
                required: true,
                ...inputProps
            })
        ]
    });
};
CustomInputEmail.propTypes = {
    labelText: (external_prop_types_default()).node,
    labelProps: (external_prop_types_default()).object,
    formControlProps: (external_prop_types_default()).object,
    inputRootCustomClasses: (external_prop_types_default()).string,
    error: (external_prop_types_default()).bool,
    success: (external_prop_types_default()).bool,
    white: (external_prop_types_default()).bool
};

;// CONCATENATED MODULE: ./components/CustomInput/CustomInputTelefone.js









const CustomInputTelefone_useStyles = (0,styles_.makeStyles)(customInputStyle/* default */.Z);
function CustomInputTelefone(props) {
    const classes = CustomInputTelefone_useStyles();
    const { formControlProps , labelText , labelProps , inputProps , error , success , white , inputRootCustomClasses , onChange , required  } = props;
    const labelClasses = external_classnames_default()({
        [classes.labelRootError]: error,
        [classes.labelRootSuccess]: success && !error
    });
    const underlineClasses = external_classnames_default()({
        [classes.underlineError]: error,
        [classes.underlineSuccess]: success && !error,
        [classes.underline]: true,
        [classes.whiteUnderline]: white
    });
    const marginTop = external_classnames_default()({
        [inputRootCustomClasses]: inputRootCustomClasses !== undefined
    });
    const inputClasses = external_classnames_default()({
        [classes.input]: true,
        [classes.whiteInput]: white
    });
    const formControlClasses = external_classnames_default()(formControlProps?.className, classes.formControl);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((FormControl_default()), {
        ...formControlProps,
        className: formControlClasses,
        children: [
            labelText && /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                className: `${classes.labelRoot} ${labelClasses}`,
                ...labelProps,
                children: labelText
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                classes: {
                    input: inputClasses,
                    root: marginTop,
                    disabled: classes.disabled,
                    underline: underlineClasses
                },
                onChange: onChange,
                required: true,
                ...inputProps
            })
        ]
    });
}
CustomInputTelefone.propTypes = {
    labelText: (external_prop_types_default()).node,
    labelProps: (external_prop_types_default()).object,
    formControlProps: (external_prop_types_default()).object,
    inputRootCustomClasses: (external_prop_types_default()).string,
    error: (external_prop_types_default()).bool,
    success: (external_prop_types_default()).bool,
    white: (external_prop_types_default()).bool
};
/* harmony default export */ const CustomInput_CustomInputTelefone = (CustomInputTelefone);

;// CONCATENATED MODULE: ./components/CustomInput/CustomInputNome.js


// nodejs library to set properties for components

// nodejs library that concatenates classes

// @material-ui/core components





const CustomInputNome_useStyles = (0,styles_.makeStyles)(customInputStyle/* default */.Z);
function CustomInputNome(props) {
    const classes = CustomInputNome_useStyles();
    const { formControlProps , labelText , id , labelProps , inputProps , error , white , inputRootCustomClasses , success , onChange , required  } = props;
    const labelClasses = external_classnames_default()({
        [" " + classes.labelRootError]: error,
        [" " + classes.labelRootSuccess]: success && !error
    });
    const underlineClasses = external_classnames_default()({
        [classes.underlineError]: error,
        [classes.underlineSuccess]: success && !error,
        [classes.underline]: true,
        [classes.whiteUnderline]: white
    });
    const marginTop = external_classnames_default()({
        [inputRootCustomClasses]: inputRootCustomClasses !== undefined
    });
    const inputClasses = external_classnames_default()({
        [classes.input]: true,
        [classes.whiteInput]: white
    });
    var formControlClasses;
    if (formControlProps !== undefined) {
        formControlClasses = external_classnames_default()(formControlProps.className, classes.formControl);
    } else {
        formControlClasses = classes.formControl;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((FormControl_default()), {
        ...formControlProps,
        className: formControlClasses,
        children: [
            labelText !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                className: classes.labelRoot + " " + labelClasses,
                ...labelProps,
                children: labelText
            }) : null,
            /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                classes: {
                    root: marginTop,
                    disabled: classes.disabled,
                    underline: underlineClasses
                },
                onChange: onChange,
                required: true,
                ...inputProps
            })
        ]
    });
};
CustomInputNome.propTypes = {
    labelText: (external_prop_types_default()).node,
    labelProps: (external_prop_types_default()).object,
    formControlProps: (external_prop_types_default()).object,
    inputRootCustomClasses: (external_prop_types_default()).string,
    error: (external_prop_types_default()).bool,
    success: (external_prop_types_default()).bool,
    white: (external_prop_types_default()).bool
};

;// CONCATENATED MODULE: ./pages-sections/LandingPage-Sections/WorkSection.js










const WorkSection_useStyles = (0,styles_.makeStyles)(landingPageSections_workStyle);
function WorkSection() {
    const classes = WorkSection_useStyles();
    const { 0: conteudo , 1: setConteudo  } = (0,external_react_.useState)({
        nome: "",
        email: "",
        telefone: ""
    });
    const onNomeChange = (e)=>{
        setConteudo({
            ...conteudo,
            nome: e.target.value
        });
        console.log("onNomeChange foi chamado com valor:", e.target.value);
    };
    const onEmailChange = (e)=>{
        setConteudo({
            ...conteudo,
            email: e.target.value
        });
        console.log("onEmailChange foi chamado com valor:", e.target.value);
    };
    const onTelefoneChange = (e)=>{
        setConteudo({
            ...conteudo,
            telefone: e.target.value
        });
        console.log("onTelefoneChange foi chamado com valor:", e.target.value);
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (conteudo.name === "" || conteudo.email === "" || conteudo.telefone === "") {
            alert("Por favor, preencha todos os campos obrigat\xf3rios.");
        }
        const conteudoJson = JSON.stringify(conteudo);
        console.log("Conteudo   " + conteudoJson);
        const formData = new FormData();
        formData.append("nome", conteudo.nome);
        formData.append("email", conteudo.email);
        formData.append("telefone", conteudo.telefone);
        try {
            const response = await fetch("https://curuca.onrender.com/addRow", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                body: JSON.stringify(Object.fromEntries(formData))
            });
            if (response.ok) {
                window.location.href = "https://dadosenviados.netlify.app";
            } else {
                alert("Erro ao enviar o formul\xe1rio");
            }
        } catch (error) {
            alert("Erro ao enviar o formul\xe1rio");
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridContainer/* default */.Z, {
            justify: "center",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                xs: 12,
                sm: 12,
                md: 8,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: classes.title,
                        children: "Fale com um consultor sobre o Residencial Curu\xe7a"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: classes.description,
                        children: "Saiba como realizar o sonho de morar em um apartamento novo com toda a qualidade de vida que voc\xea deseja no centro de Mau\xe1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("form", {
                        onSubmit: handleSubmit,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridContainer/* default */.Z, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 12,
                                    md: 12,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInputNome, {
                                        labelText: "Nome Completo",
                                        name: "nome",
                                        onChange: onNomeChange,
                                        value: conteudo.nome,
                                        formControlProps: {
                                            fullWidth: true
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 12,
                                    md: 12,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInputEmail, {
                                        labelText: "E-mail",
                                        name: "email",
                                        onChange: onEmailChange,
                                        required: true,
                                        type: "email",
                                        value: conteudo.email,
                                        formControlProps: {
                                            fullWidth: true
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 12,
                                    md: 12,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomInput_CustomInputTelefone, {
                                        labelText: "Telefone",
                                        type: "tel",
                                        name: "telefone",
                                        onChange: onTelefoneChange,
                                        required: true,
                                        value: conteudo.telefone,
                                        formControlProps: {
                                            fullWidth: true
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 12,
                                    md: 12,
                                    className: classes.textCenter,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CustomButtons_Button/* default */.Z, {
                                        type: "submit",
                                        color: "warning",
                                        children: "Quero Saber Tudo!"
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./pages-sections/Components-Sections/SectionCarousel.js
var SectionCarousel = __webpack_require__(6382);
// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__(8130);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: external "@material-ui/icons/LocationOn"
var LocationOn_ = __webpack_require__(9616);
var LocationOn_default = /*#__PURE__*/__webpack_require__.n(LocationOn_);
// EXTERNAL MODULE: ./styles/jss/nextjs-material-kit/pages/componentsSections/carouselStyle.js
var carouselStyle = __webpack_require__(5246);
;// CONCATENATED MODULE: ./pages-sections/Components-Sections/PlantsCarrousel.js


// react component for creating beautiful carousel

// @material-ui/core components

// @material-ui/icons

// core components




const PlantsCarrousel_useStyles = (0,styles_.makeStyles)(carouselStyle/* default */.Z);
function PlantasCarousel() {
    const classes = PlantsCarrousel_useStyles();
    const settings = {
        dots: true,
        infinite: true,
        speed: 400,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: classes.section,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: classes.container,
            children: /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridContainer/* default */.Z, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridItem/* default */.Z, {
                    xs: 12,
                    sm: 12,
                    md: 8,
                    className: classes.marginAuto,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Card_Card/* default */.Z, {
                        carousel: true,
                        sx: {
                            width: "100%",
                            height: "100%"
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_slick_default()), {
                            ...settings,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/arrombado.png",
                                            className: "slick-image"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "slick-caption",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((LocationOn_default()), {
                                                        className: "slick-icons"
                                                    }),
                                                    "Banheiro"
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/bemlegal.png",
                                            className: "slick-image"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "slick-caption",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((LocationOn_default()), {
                                                        className: "slick-icons"
                                                    }),
                                                    "Cozinha"
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/cufedido.png",
                                            className: "slick-image"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "slick-caption",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((LocationOn_default()), {
                                                        className: "slick-icons"
                                                    }),
                                                    "Quarto do casal"
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/apbunito.png",
                                            className: "slick-image"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "slick-caption",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((LocationOn_default()), {
                                                        className: "slick-icons"
                                                    }),
                                                    "Quarto Individual"
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./pages/landing.js


// nodejs library that concatenates classes

// @material-ui/core components

// @material-ui/icons
// core components












// Sections for this page






const dashboardRoutes = [];
const landing_useStyles = (0,styles_.makeStyles)(landingPage);
const scrollToSection = (ref)=>{
    window.scrollTo({
        top: ref.current.offsetTop,
        behavior: "smooth"
    });
};
const MyComponent = ()=>{
    const sectionRef1 = useRef(null);
};
const handleClick = ()=>{
    scrollToSection(sectionRef);
};
function LandingPage(props) {
    const classes = landing_useStyles();
    const { ...rest } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "Inicio",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Curu\xe7a - Jireh Im\xf3veis"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Conhe\xe7a o im\xf3vel residencial Curu\xe7a, localizado na regi\xe3o de Mau\xe1 e financiado pelo programa Minha Casa, Minha Vida."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: "Curu\xe7a - Jireh Im\xf3veis"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:description",
                        content: "Conhe\xe7a o im\xf3vel residencial Curu\xe7a, localizado na regi\xe3o de Mau\xe1 e financiado pelo programa Minha Casa, Minha Vida."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:url",
                        content: "URL_DA_PAGINA"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                color: "transparent",
                routes: dashboardRoutes,
                // brand="Jireh"
                image: "/img/jirehlogo.png",
                rightLinks: /*#__PURE__*/ jsx_runtime_.jsx(HeaderLinks/* default */.Z, {}),
                fixed: true,
                changeColorOnScroll: {
                    height: 400,
                    color: "warning"
                },
                ...rest
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Parallax/* default */.Z, {
                filter: true,
                responsive: true,
                image: "/img/curucanovo.jpeg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: classes.container,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridContainer/* default */.Z, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(GridItemT_GridItem, {
                                    xs: 12,
                                    sm: 12,
                                    md: 12,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: classes.title,
                                        children: "O RESIDENCIAL QUE VOC\xca ESTAVA ESPERANDO"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                                    xs: 12,
                                    sm: 12,
                                    md: 0,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: classes.responsiveSubtitle,
                                            children: "Seu apartamento na regi\xe3o mais  privilegiada de Mau\xe1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridItem/* default */.Z, {
                                            xs: 12,
                                            sm: 12,
                                            md: 0,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CustomButtons_Button/* default */.Z, {
                                                href: "https://wa.me/5511996430891",
                                                color: "warning",
                                                size: "sm",
                                                children: [
                                                    "WhatsApp",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "img/faces/wpp.png",
                                                        alt: "wpp",
                                                        width: 30,
                                                        height: 30,
                                                        className: classes.imgRoundedCircle + " " + classes.imgFluid
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: classes.containerTwo
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: external_classnames_default()(classes.main, classes.mainRaised),
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "Curuca",
                    className: classes.container,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(ProductSection, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            id: "Fotos",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(SectionCarousel/* default */.Z, {})
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                                justify: "center",
                                style: {
                                    color: "#3C4858"
                                },
                                xs: 12,
                                sm: 12,
                                md: 8,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        id: "Localizacao"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: classes.titleOne,
                                        style: {
                                            color: "#3C4858"
                                        },
                                        children: "Localiza\xe7\xe3o"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: classes.description,
                                        children: "Venha morar na Vila Guarani em Mau\xe1! Os apartamentos do Residencial Curu\xe7\xe1 s\xe3o perfeitos para voc\xea e sua fam\xedlia, com su\xedte e sacada Grill. N\xe3o perca essa oportunidade!"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Grid, {
                                xs: 10,
                                sm: 6,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                    src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1827.1364269155135!2d-46.45080681120912!3d-23.666198444681985!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x654442a5c09aadc9%3A0xfda6367f6cf0b6ef!2sResidencial%20Curu%C3%A7a!5e0!3m2!1spt-BR!2sbr!4v1692117106894!5m2!1spt-BR!2sbr",
                                    width: "300",
                                    height: "300",
                                    style: {
                                        border: 0
                                    },
                                    allowfullscreen: "",
                                    loading: "lazy",
                                    referrerpolicy: "no-referrer-when-downgrade"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Grid_GridItem/* default */.Z, {
                                justify: "center",
                                style: {
                                    color: "#3C4858"
                                },
                                xs: 12,
                                sm: 12,
                                md: 8,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        id: "Plantas"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: classes.titleOne,
                                        style: {
                                            color: "#3C4858"
                                        },
                                        children: "Plantas"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: classes.description,
                                        children: "O Residencial Curu\xe7a oferece uma variedade de apartamentos, com seis unidades por andar e dois elevadores. S\xe3o disponibilizados cinco tipos de apartamentos, com tamanhos que variam de 53m\xb2 a 139m\xb2. As plantas foram projetadas para proporcionar conforto e praticidade aos moradores, atendendo \xe0s diferentes necessidades e prefer\xeancias."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Grid_GridContainer/* default */.Z, {
                            justify: "center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Grid, {
                                xs: 12,
                                sm: 12,
                                md: 4
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(PlantasCarousel, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(WorkSection, {})
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "Contato",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
            })
        ]
    });
};


/***/ })

};
;